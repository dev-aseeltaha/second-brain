package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Category / Drawer in the Second Brain.
 * e.g., أدوات AI, تطبيقات أندرويد, مشاريع مفتوحة, برامج ويندوز, وكلاء ذكاء اصطناعي, أفكار للتنفيذ لاحقاً
 */
@Entity(tableName = "categories")
data class Category(
    @PrimaryKey
    val id: String,
    val nameArabic: String,
    val iconKey: String = "folder",
    val colorHex: String = "#1E3A8A",
    val isSystemDefault: Boolean = false,
    val isProtected: Boolean = false, // Protected by App Lock PIN / Biometric
    val sortOrder: Int = 0
) {
    companion object {
        fun getDefaultCategories(): List<Category> = listOf(
            Category("ai_tools", "أدوات ذكاء اصطناعي", "psychology", "#6366F1", isSystemDefault = true, sortOrder = 0),
            Category("android_apps", "تطبيقات أندرويد", "android", "#10B981", isSystemDefault = true, sortOrder = 1),
            Category("open_source", "مشاريع مفتوحة المصدر", "code", "#0D9488", isSystemDefault = true, sortOrder = 2),
            Category("windows_software", "برامج ويندوز وأدوات مكتبية", "computer", "#0284C7", isSystemDefault = true, sortOrder = 3),
            Category("ai_agents", "وكلاء ذكاء اصطناعي (Agents)", "smart_toy", "#8B5CF6", isSystemDefault = true, sortOrder = 4),
            Category("ideas_later", "أفكار للتنفيذ لاحقاً", "lightbulb", "#F59E0B", isSystemDefault = true, isProtected = true, sortOrder = 5)
        )
    }
}
