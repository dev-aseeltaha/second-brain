package com.example.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Category
import com.example.network.GeminiAiService
import com.example.network.WebScraper
import com.example.ui.components.CategoryIconHelper
import com.example.ui.theme.BrainBackground
import com.example.ui.theme.BrainOutline
import com.example.ui.theme.BrainPrimary
import com.example.ui.theme.BrainSecondary
import com.example.ui.theme.BrainSurface
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun QuickCaptureSheet(
    sheetState: SheetState,
    initialUrl: String?,
    initialText: String?,
    categories: List<Category>,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        url: String?,
        notes: String,
        categoryId: String,
        tags: List<String>,
        reminderTime: Long?
    ) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var url by remember { mutableStateOf(initialUrl ?: "") }
    var title by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf(initialText ?: "") }
    var notes by remember { mutableStateOf("") }
    var selectedCategoryId by remember {
        mutableStateOf(categories.firstOrNull()?.id ?: "ai_tools")
    }
    val tags = remember { mutableStateListOf<String>() }
    var newTagInput by remember { mutableStateOf("") }
    var reminderTimestamp by remember { mutableStateOf<Long?>(null) }
    var isScrapingAi by remember { mutableStateOf(false) }

    // Pre-populate if initialUrl provided via share intent
    LaunchedEffect(initialUrl) {
        if (!initialUrl.isNullOrBlank()) {
            url = initialUrl
            // Auto scrape in background for instant convenience
            isScrapingAi = true
            coroutineScope.launch {
                val scraped = WebScraper.scrapeUrl(initialUrl)
                if (title.isBlank()) title = scraped.title
                if (summary.isBlank() && scraped.description.isNotBlank()) summary = scraped.description

                // Auto category guess
                scraped.suggestedCategory?.let { guessedCat ->
                    if (categories.any { it.id == guessedCat }) {
                        selectedCategoryId = guessedCat
                    }
                }
                scraped.suggestedTags.forEach { if (!tags.contains(it)) tags.add(it) }

                // Quick AI summary call
                val ai = GeminiAiService.generateSummary(scraped.title, initialUrl, scraped.fullTextExcerpt)
                if (ai.summary.isNotBlank()) summary = ai.summary
                ai.suggestedCategory?.let { if (categories.any { c -> c.id == it }) selectedCategoryId = it }
                ai.suggestedTags.forEach { if (!tags.contains(it)) tags.add(it) }

                isScrapingAi = false
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = BrainSurface,
        modifier = Modifier.testTag("quick_capture_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (!initialUrl.isNullOrBlank()) "التقاط سريع للمحتوى" else "إضافة فكرة / أداة جديدة",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrainPrimary
                    )
                    Text(
                        text = "صندوق ودائعك المعرفي الذكي",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Categories Selector Row
            Text(
                text = "اختر التصنيف المناسب:",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isSelected = cat.id == selectedCategoryId
                    val catColor = CategoryIconHelper.parseColor(cat.colorHex)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) catColor else BrainBackground)
                            .border(1.dp, if (isSelected) catColor else BrainOutline, RoundedCornerShape(10.dp))
                            .clickable { selectedCategoryId = cat.id }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                            .testTag("category_select_${cat.id}")
                    ) {
                        Icon(
                            imageVector = CategoryIconHelper.getIcon(cat.iconKey),
                            contentDescription = null,
                            tint = if (isSelected) Color.White else catColor,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = cat.nameArabic,
                            fontSize = 12.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else Color(0xFF1E293B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // URL input with AI button
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                label = { Text("رابط الموقع أو الأداة (اختياري)") },
                placeholder = { Text("https://example.com/tool") },
                singleLine = true,
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = BrainPrimary)
                },
                trailingIcon = {
                    if (isScrapingAi) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else if (url.isNotBlank()) {
                        IconButton(onClick = {
                            isScrapingAi = true
                            coroutineScope.launch {
                                val scraped = WebScraper.scrapeUrl(url)
                                if (title.isBlank()) title = scraped.title
                                val ai = GeminiAiService.generateSummary(scraped.title, url, scraped.fullTextExcerpt)
                                summary = ai.summary.ifBlank { scraped.description }
                                ai.suggestedCategory?.let { if (categories.any { c -> c.id == it }) selectedCategoryId = it }
                                ai.suggestedTags.forEach { if (!tags.contains(it)) tags.add(it) }
                                isScrapingAi = false
                            }
                        }) {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "استخراج ذكي", tint = BrainSecondary)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_url"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrainPrimary,
                    unfocusedBorderColor = BrainOutline
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("اسم الأداة أو عنوان الفكرة *") },
                placeholder = { Text("مثال: Claude 3.5 Sonnet أو مكتبة Compose") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_title"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrainPrimary,
                    unfocusedBorderColor = BrainOutline
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Summary / Brief (mandatory or auto-generated)
            OutlinedTextField(
                value = summary,
                onValueChange = { summary = it },
                label = { Text("النبذة التوضيحية (يكتبها الذكاء الاصطناعي أو اكتبها بنفسك) *") },
                placeholder = { Text("ما هي وظيفة هذه الأداة ولماذا حفظتها؟") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_summary"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrainPrimary,
                    unfocusedBorderColor = BrainOutline
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("ملاحظات إضافية أو كود أو أفكار (اختياري)") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_notes"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrainPrimary,
                    unfocusedBorderColor = BrainOutline
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Tags section
            Text(
                text = "الوسوم والتصنيفات الدقيقة:",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newTagInput,
                    onValueChange = { newTagInput = it },
                    placeholder = { Text("#مجاني، #أندرويد…") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val trimmed = newTagInput.trim()
                        if (trimmed.isNotBlank()) {
                            val formatted = if (trimmed.startsWith("#")) trimmed else "#$trimmed"
                            if (!tags.contains(formatted)) tags.add(formatted)
                            newTagInput = ""
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrainPrimary)
                ) {
                    Text("إضافة")
                }
            }

            if (tags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    tags.forEach { tag ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color(0xFFE0E7FF), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = tag, fontSize = 12.sp, color = Color(0xFF3730A3))
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "حذف الوسم",
                                tint = Color(0xFF4338CA),
                                modifier = Modifier
                                    .size(14.dp)
                                    .clickable { tags.remove(tag) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Reminder (Test it Later)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(BrainBackground)
                    .border(1.dp, BrainOutline, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Alarm,
                        contentDescription = null,
                        tint = if (reminderTimestamp != null) Color(0xFFD97706) else Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "تذكير (جرّبه لاحقاً)",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = if (reminderTimestamp != null) {
                                SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(reminderTimestamp!!))
                            } else {
                                "حدد موعداً لمراجعة هذه الأداة"
                            },
                            fontSize = 11.5.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                if (reminderTimestamp == null) {
                    OutlinedButton(
                        onClick = {
                            showDateTimePicker(context) { chosenMillis ->
                                reminderTimestamp = chosenMillis
                            }
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("جدولة تذكير", fontSize = 12.sp)
                    }
                } else {
                    IconButton(onClick = { reminderTimestamp = null }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إلغاء التذكير", tint = Color.Red)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Save Action Button
            Button(
                onClick = {
                    val finalTitle = title.ifBlank { url.ifBlank { "فكرة جديدة" } }
                    val finalSummary = summary.ifBlank { "أداة ورابط محفوظ للمراجعة." }
                    onSave(
                        finalTitle,
                        url.ifBlank { null },
                        notes,
                        selectedCategoryId,
                        tags.toList(),
                        reminderTimestamp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_brain_item_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrainPrimary)
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("حفظ في العقل الرقمي", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

fun showDateTimePicker(context: Context, onDateTimeSelected: (Long) -> Unit) {
    val calendar = Calendar.getInstance()
    DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, month)
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            TimePickerDialog(
                context,
                { _, hourOfDay, minute ->
                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                    calendar.set(Calendar.MINUTE, minute)
                    calendar.set(Calendar.SECOND, 0)
                    onDateTimeSelected(calendar.timeInMillis)
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true
            ).show()
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    ).show()
}
