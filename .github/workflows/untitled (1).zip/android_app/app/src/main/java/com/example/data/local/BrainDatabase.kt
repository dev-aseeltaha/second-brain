package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BrainItem
import com.example.data.model.BrainTypeConverters
import com.example.data.model.Category
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [BrainItem::class, Category::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(BrainTypeConverters::class)
abstract class BrainDatabase : RoomDatabase() {

    abstract fun brainItemDao(): BrainItemDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        @Volatile
        private var INSTANCE: BrainDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): BrainDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BrainDatabase::class.java,
                    "mind_vault_second_brain.db"
                )
                    .addCallback(BrainDatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class BrainDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    // Prepopulate default system categories
                    database.categoryDao().insertCategories(Category.getDefaultCategories())

                    // Prepopulate initial onboarding items showcasing features
                    val sampleItems = listOf(
                        BrainItem(
                            id = "welcome_1",
                            title = "Gemini 3.5 Flash",
                            summary = "أحدث نموذج متعدد الوسائط فائق السرعة من جوجل، مصمم للمهام المعقدة والتلخيص الذكي بزمن استجابة فوري.",
                            originalUrl = "https://ai.google.dev",
                            notesRichText = "**ملاحظات أساسية:**\n- سرعة استجابة فائقة\n- نافذة سياق ضخمة تصل لمليون رمز\n- استخراج دقيق للمعلومات",
                            categoryId = "ai_tools",
                            tags = listOf("#ذكاء_اصطناعي", "#جوجل", "#موصى_به"),
                            offlineArchiveContent = "Gemini 3.5 Flash is Google's multimodal AI model offering low latency, cost efficiency, and advanced reasoning.",
                            isPinned = true
                        ),
                        BrainItem(
                            id = "welcome_2",
                            title = "Jetpack Compose",
                            summary = "حزمة أدوات أندرويد العصرية لبناء واجهات مستخدم مذهلة تعتمد على البرمجة التصريحية والتوافق مع نظام Material 3.",
                            originalUrl = "https://developer.android.com/compose",
                            notesRichText = "مكتبة بناء الواجهات الرسمية لأندرويد.\n```kotlin\n@Composable\nfun SecondBrainApp() {\n    Text(\"مرحباً بك في عقلك الرقمي!\")\n}\n```",
                            categoryId = "android_apps",
                            tags = listOf("#أندرويد", "#تطوير", "#واجهات")
                        )
                    )
                    database.brainItemDao().insertItems(sampleItems)
                }
            }
        }
    }
}
