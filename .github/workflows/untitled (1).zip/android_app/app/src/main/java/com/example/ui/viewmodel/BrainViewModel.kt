package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BrainApplication
import com.example.data.model.BrainItem
import com.example.data.model.Category
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class BrainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as BrainApplication
    private val repository = app.repository
    val securityManager = app.securityManager

    // UI State variables
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<String?>(null) // null = all
    val selectedCategoryId: StateFlow<String?> = _selectedCategoryId.asStateFlow()

    private val _selectedTag = MutableStateFlow<String?>(null)
    val selectedTag: StateFlow<String?> = _selectedTag.asStateFlow()

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Category.getDefaultCategories())

    // Raw items stream from DB based on search
    private val rawItems: StateFlow<List<BrainItem>> = _searchQuery
        .flatMapLatest { query -> repository.searchItems(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered items (applying category tab and tag filter)
    val filteredItems: StateFlow<List<BrainItem>> = combine(
        rawItems,
        _selectedCategoryId,
        _selectedTag
    ) { items, catId, tag ->
        items.filter { item ->
            val matchCategory = catId == null || item.categoryId == catId
            val matchTag = tag == null || item.tags.contains(tag)
            matchCategory && matchTag
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All available tags extracted from existing items
    val allTags: StateFlow<List<String>> = rawItems.combine(_selectedCategoryId) { items, catId ->
        val filtered = if (catId != null) items.filter { it.categoryId == catId } else items
        filtered.flatMap { it.tags }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently selected item for detail / editing
    private val _activeItem = MutableStateFlow<BrainItem?>(null)
    val activeItem: StateFlow<BrainItem?> = _activeItem.asStateFlow()

    // Dialog & Navigation states
    private val _isQuickCaptureOpen = MutableStateFlow(false)
    val isQuickCaptureOpen: StateFlow<Boolean> = _isQuickCaptureOpen.asStateFlow()

    private val _quickCapturePrefillUrl = MutableStateFlow<String?>("")
    val quickCapturePrefillUrl: StateFlow<String?> = _quickCapturePrefillUrl.asStateFlow()

    private val _quickCapturePrefillText = MutableStateFlow<String?>("")
    val quickCapturePrefillText: StateFlow<String?> = _quickCapturePrefillText.asStateFlow()

    private val _isCategoriesManageOpen = MutableStateFlow(false)
    val isCategoriesManageOpen: StateFlow<Boolean> = _isCategoriesManageOpen.asStateFlow()

    private val _isExportDialogOpen = MutableStateFlow(false)
    val isExportDialogOpen: StateFlow<Boolean> = _isExportDialogOpen.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    // App Lock Security State
    private val _isUnlocked = MutableStateFlow(!securityManager.isAppLockEnabled())
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val _showPinPrompt = MutableStateFlow(false)
    val showPinPrompt: StateFlow<Boolean> = _showPinPrompt.asStateFlow()

    init {
        // Check if initial app lock is required
        if (securityManager.isAppLockEnabled()) {
            _isUnlocked.value = false
            _showPinPrompt.value = true
        }
    }

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onSelectCategory(categoryId: String?) {
        _selectedCategoryId.value = categoryId
    }

    fun onSelectTag(tag: String?) {
        _selectedTag.value = if (_selectedTag.value == tag) null else tag
    }

    fun openItemDetail(item: BrainItem) {
        // If item or category is protected and app is locked, require verification
        _activeItem.value = item
    }

    fun closeItemDetail() {
        _activeItem.value = null
    }

    fun openQuickCapture(url: String? = null, text: String? = null) {
        _quickCapturePrefillUrl.value = url
        _quickCapturePrefillText.value = text
        _isQuickCaptureOpen.value = true
    }

    fun closeQuickCapture() {
        _isQuickCaptureOpen.value = false
        _quickCapturePrefillUrl.value = null
        _quickCapturePrefillText.value = null
    }

    fun openCategoriesManage(open: Boolean) {
        _isCategoriesManageOpen.value = open
    }

    fun openExportDialog(open: Boolean) {
        _isExportDialogOpen.value = open
    }

    fun openSettings(open: Boolean) {
        _isSettingsOpen.value = open
    }

    fun saveNewItem(
        title: String,
        url: String?,
        notes: String,
        categoryId: String,
        tags: List<String>,
        imageUri: String? = null,
        ocrText: String = "",
        reminderTime: Long? = null
    ) {
        viewModelScope.launch {
            repository.saveItem(
                title = title,
                url = url?.trim()?.ifBlank { null },
                notes = notes,
                categoryId = categoryId,
                tags = tags,
                imageUri = imageUri,
                ocrText = ocrText,
                reminderTime = reminderTime
            )
            closeQuickCapture()
        }
    }

    fun updateItem(item: BrainItem) {
        viewModelScope.launch {
            repository.updateItem(item)
            _activeItem.value = item
        }
    }

    fun togglePin(item: BrainItem) {
        viewModelScope.launch {
            repository.togglePin(item)
        }
    }

    fun deleteItem(id: String) {
        viewModelScope.launch {
            repository.deleteItem(id)
            if (_activeItem.value?.id == id) {
                _activeItem.value = null
            }
        }
    }

    fun reEnrichItem(item: BrainItem) {
        viewModelScope.launch {
            val updated = repository.reEnrichItemNow(item)
            if (_activeItem.value?.id == item.id) {
                _activeItem.value = updated
            }
        }
    }

    fun addCategory(nameArabic: String, iconKey: String, colorHex: String, isProtected: Boolean) {
        viewModelScope.launch {
            val newCategory = Category(
                id = "cat_${System.currentTimeMillis()}",
                nameArabic = nameArabic,
                iconKey = iconKey,
                colorHex = colorHex,
                isProtected = isProtected
            )
            repository.addCategory(newCategory)
        }
    }

    fun deleteCategory(id: String) {
        viewModelScope.launch {
            repository.deleteCategory(id)
            if (_selectedCategoryId.value == id) {
                _selectedCategoryId.value = null
            }
        }
    }

    private val syncManager = app.syncManager

    // Cloud Sync State
    private val _syncMessage = MutableStateFlow<String?>(null)
    val syncMessage: StateFlow<String?> = _syncMessage.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    val lastSyncTime: Long
        get() = syncManager.getLastSyncTime()

    // Category Protection State
    private val _unlockedCategoryIds = MutableStateFlow<Set<String>>(emptySet())
    val unlockedCategoryIds: StateFlow<Set<String>> = _unlockedCategoryIds.asStateFlow()

    private val _pendingCategoryUnlock = MutableStateFlow<Category?>(null)
    val pendingCategoryUnlock: StateFlow<Category?> = _pendingCategoryUnlock.asStateFlow()

    fun selectCategoryWithProtectionCheck(category: Category?) {
        if (category == null) {
            _selectedCategoryId.value = null
            return
        }
        if (category.isProtected && !_unlockedCategoryIds.value.contains(category.id)) {
            _pendingCategoryUnlock.value = category
        } else {
            _selectedCategoryId.value = category.id
        }
    }

    fun verifyCategoryUnlockPin(pin: String): Boolean {
        val success = securityManager.verifyPin(pin)
        if (success) {
            val cat = _pendingCategoryUnlock.value
            if (cat != null) {
                _unlockedCategoryIds.value = _unlockedCategoryIds.value + cat.id
                _selectedCategoryId.value = cat.id
                _pendingCategoryUnlock.value = null
            }
        }
        return success
    }

    fun unlockCategoryBiometric() {
        val cat = _pendingCategoryUnlock.value
        if (cat != null) {
            _unlockedCategoryIds.value = _unlockedCategoryIds.value + cat.id
            _selectedCategoryId.value = cat.id
            _pendingCategoryUnlock.value = null
        }
    }

    fun cancelCategoryUnlock() {
        _pendingCategoryUnlock.value = null
    }

    // Cloud Sync Actions
    fun syncWithCloud() {
        viewModelScope.launch {
            _isSyncing.value = true
            _syncMessage.value = "جارٍ رفع البيانات إلى سحابة Firestore…"
            val allItems = rawItems.value
            val allCats = repository.getAllCategoriesDirect()
            val result = syncManager.syncLocalToCloud(allItems, allCats)
            _isSyncing.value = false
            when (result) {
                is com.example.data.sync.SyncResult.Success -> {
                    _syncMessage.value = result.message
                }
                is com.example.data.sync.SyncResult.Error -> {
                    _syncMessage.value = result.errorMessage
                }
            }
        }
    }

    fun restoreFromCloud() {
        viewModelScope.launch {
            _isSyncing.value = true
            _syncMessage.value = "جارٍ استعادة البيانات من سحابة Firestore…"
            val result = syncManager.restoreFromCloud()
            _isSyncing.value = false
            when (result) {
                is com.example.data.sync.RestoreResult.Success -> {
                    repository.insertRestoredCategories(result.categories)
                    repository.insertRestoredItems(result.items)
                    _syncMessage.value = "تمت استعادة ${result.items.size} عنصر و${result.categories.size} تصنيف بنجاح"
                }
                is com.example.data.sync.RestoreResult.Error -> {
                    _syncMessage.value = result.errorMessage
                }
            }
        }
    }

    fun clearSyncMessage() {
        _syncMessage.value = null
    }

    // Security Handlers
    fun onVerifyPin(pin: String): Boolean {
        val success = securityManager.verifyPin(pin)
        if (success) {
            _isUnlocked.value = true
            _showPinPrompt.value = false
        }
        return success
    }

    fun onBiometricSuccess() {
        _isUnlocked.value = true
        _showPinPrompt.value = false
    }

    fun lockVault() {
        if (securityManager.isAppLockEnabled()) {
            _isUnlocked.value = false
            _showPinPrompt.value = true
        }
    }

    fun enableAppLock(pin: String) {
        securityManager.setPin(pin)
        securityManager.setAppLockEnabled(true)
    }

    fun disableAppLock() {
        securityManager.clearPin()
        _isUnlocked.value = true
        _showPinPrompt.value = false
    }
}
