package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import com.example.security.BiometricAuthHelper
import com.example.ui.dialogs.CategoryLockDialog
import com.example.ui.dialogs.CategoriesManageDialog
import com.example.ui.dialogs.ExportDialog
import com.example.ui.dialogs.SecurityLockScreen
import com.example.ui.dialogs.SettingsDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ItemDetailScreen
import com.example.ui.screens.QuickCaptureSheet
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BrainViewModel

class MainActivity : FragmentActivity() {

    private val viewModel: BrainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle initial Share Intent (from Twitter, YouTube, Browser, etc.)
        handleIncomingIntent(intent)

        setContent {
            MyApplicationTheme {
                val isUnlocked by viewModel.isUnlocked.collectAsState()
                val activeItem by viewModel.activeItem.collectAsState()
                val items by viewModel.filteredItems.collectAsState()
                val categories by viewModel.categories.collectAsState()
                val selectedCategoryId by viewModel.selectedCategoryId.collectAsState()
                val selectedTag by viewModel.selectedTag.collectAsState()
                val searchQuery by viewModel.searchQuery.collectAsState()
                val allTags by viewModel.allTags.collectAsState()

                val isQuickCaptureOpen by viewModel.isQuickCaptureOpen.collectAsState()
                val prefillUrl by viewModel.quickCapturePrefillUrl.collectAsState()
                val prefillNotes by viewModel.quickCapturePrefillText.collectAsState()

                val isCategoriesManageOpen by viewModel.isCategoriesManageOpen.collectAsState()
                val isExportDialogOpen by viewModel.isExportDialogOpen.collectAsState()
                val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
                val pendingCategoryUnlock by viewModel.pendingCategoryUnlock.collectAsState()

                val syncMessage by viewModel.syncMessage.collectAsState()
                val isSyncing by viewModel.isSyncing.collectAsState()

                LaunchedEffect(syncMessage) {
                    syncMessage?.let {
                        Toast.makeText(this@MainActivity, it, Toast.LENGTH_LONG).show()
                        viewModel.clearSyncMessage()
                    }
                }

                val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

                Box(modifier = Modifier.fillMaxSize()) {
                    // 1. Security Lock Screen Check
                    if (!isUnlocked) {
                        SecurityLockScreen(
                            onVerifyPin = { pin -> viewModel.onVerifyPin(pin) },
                            onBiometricUnlock = {
                                if (BiometricAuthHelper.isBiometricAvailable(this@MainActivity)) {
                                    BiometricAuthHelper.promptBiometric(
                                        activity = this@MainActivity,
                                        title = "فتح خزنة العقل الرقمي",
                                        subtitle = "المس مستشعر البصمة للمتابعة",
                                        onSuccess = { viewModel.onBiometricSuccess() },
                                        onError = { err ->
                                            Toast.makeText(this@MainActivity, err, Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                } else {
                                    Toast.makeText(this@MainActivity, "مستشعر البصمة غير متوفر، استخدم رمز PIN", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    } else if (activeItem != null) {
                        // 2. Item Detail Screen
                        val currentCategory = categories.find { it.id == activeItem?.categoryId }
                        ItemDetailScreen(
                            item = activeItem!!,
                            category = currentCategory,
                            onBack = { viewModel.closeItemDetail() },
                            onSaveUpdate = { updated -> viewModel.updateItem(updated) },
                            onTogglePin = { item -> viewModel.togglePin(item) },
                            onDelete = { id -> viewModel.deleteItem(id) },
                            onReEnrich = { item -> viewModel.reEnrichItem(item) }
                        )
                    } else {
                        // 3. Main Dashboard Screen
                        HomeScreen(
                            items = items,
                            categories = categories,
                            selectedCategoryId = selectedCategoryId,
                            selectedTag = selectedTag,
                            searchQuery = searchQuery,
                            allTags = allTags,
                            isAppLockEnabled = viewModel.securityManager.isAppLockEnabled(),
                            onSearchChange = { q -> viewModel.onSearchQueryChange(q) },
                            onSelectCategory = { id ->
                                val cat = categories.find { it.id == id }
                                viewModel.selectCategoryWithProtectionCheck(cat)
                            },
                            onSelectTag = { tag -> viewModel.onSelectTag(tag) },
                            onItemClick = { item -> viewModel.openItemDetail(item) },
                            onTogglePin = { item -> viewModel.togglePin(item) },
                            onOpenQuickCapture = { viewModel.openQuickCapture() },
                            onOpenCategoriesManage = { viewModel.openCategoriesManage(true) },
                            onOpenExport = { viewModel.openExportDialog(true) },
                            onOpenSettings = { viewModel.openSettings(true) },
                            onLockApp = { viewModel.lockVault() }
                        )
                    }

                    // Category-level PIN Unlock Dialog
                    if (pendingCategoryUnlock != null) {
                        CategoryLockDialog(
                            category = pendingCategoryUnlock!!,
                            onVerifyPin = { pin -> viewModel.verifyCategoryUnlockPin(pin) },
                            onBiometric = {
                                if (BiometricAuthHelper.isBiometricAvailable(this@MainActivity)) {
                                    BiometricAuthHelper.promptBiometric(
                                        activity = this@MainActivity,
                                        title = "فتح قسم ${pendingCategoryUnlock?.nameArabic}",
                                        subtitle = "المس مستشعر البصمة لفتح هذا القسم المحمي",
                                        onSuccess = { viewModel.unlockCategoryBiometric() },
                                        onError = { err ->
                                            Toast.makeText(this@MainActivity, err, Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                            },
                            onDismiss = { viewModel.cancelCategoryUnlock() }
                        )
                    }

                    // Quick Capture Sheet (For FAB or incoming Share Intent)
                    if (isQuickCaptureOpen) {
                        QuickCaptureSheet(
                            sheetState = sheetState,
                            initialUrl = prefillUrl,
                            initialText = prefillNotes,
                            categories = categories,
                            onDismiss = { viewModel.closeQuickCapture() },
                            onSave = { title, url, notes, categoryId, tags, reminderTime ->
                                viewModel.saveNewItem(
                                    title = title,
                                    url = url,
                                    notes = notes,
                                    categoryId = categoryId,
                                    tags = tags,
                                    reminderTime = reminderTime
                                )
                            }
                        )
                    }

                    // Categories Management Dialog
                    if (isCategoriesManageOpen) {
                        CategoriesManageDialog(
                            categories = categories,
                            onDismiss = { viewModel.openCategoriesManage(false) },
                            onAddCategory = { name, icon, color, isProtected ->
                                viewModel.addCategory(name, icon, color, isProtected)
                            },
                            onDeleteCategory = { id ->
                                viewModel.deleteCategory(id)
                            }
                        )
                    }

                    // Full Export Dialog (JSON & Markdown)
                    if (isExportDialogOpen) {
                        ExportDialog(
                            items = items,
                            categories = categories,
                            onDismiss = { viewModel.openExportDialog(false) }
                        )
                    }

                    // Settings Dialog (with Cloud Sync)
                    if (isSettingsOpen) {
                        SettingsDialog(
                            securityManager = viewModel.securityManager,
                            onDismiss = { viewModel.openSettings(false) },
                            onEnableLock = { pin -> viewModel.enableAppLock(pin) },
                            onDisableLock = { viewModel.disableAppLock() },
                            onSyncCloud = { viewModel.syncWithCloud() },
                            onRestoreCloud = { viewModel.restoreFromCloud() }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val type = intent.type

        if (Intent.ACTION_SEND == action && type != null) {
            if ("text/plain" == type) {
                val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                // Detect URL inside shared text (handles links shared directly or from apps like YouTube/X)
                val urlPattern = Regex("""https?://[^\s]+""")
                val matchedUrl = urlPattern.find(sharedText)?.value
                val cleanNotes = if (matchedUrl != null) sharedText.replace(matchedUrl, "").trim() else sharedText
                viewModel.openQuickCapture(url = matchedUrl ?: if (sharedText.startsWith("http")) sharedText else null, text = cleanNotes)
            } else if (type.startsWith("image/")) {
                viewModel.openQuickCapture(text = "تم التقاط لقطة شاشة للتحليل واستخراج النصوص")
            }
        }
    }
}
