package com.example.ui.dialogs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.security.SecurityManager
import com.example.ui.theme.BrainBackground
import com.example.ui.theme.BrainOutline
import com.example.ui.theme.BrainPrimary
import com.example.ui.theme.BrainSecondary
import com.example.ui.theme.BrainSurface

@Composable
fun SettingsDialog(
    securityManager: SecurityManager,
    onDismiss: () -> Unit,
    onEnableLock: (String) -> Unit,
    onDisableLock: () -> Unit,
    onSyncCloud: () -> Unit = {},
    onRestoreCloud: () -> Unit = {}
) {
    val context = LocalContext.current
    var isLockEnabled by remember { mutableStateOf(securityManager.isAppLockEnabled()) }
    var pinInput by remember { mutableStateOf("") }
    var showPinInput by remember { mutableStateOf(false) }

    val hasGeminiKey = try {
        BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"
    } catch (e: Throwable) {
        false
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "إعدادات العقل الرقمي",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = BrainPrimary
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Section: App Lock
                Text(
                    text = "الأمان والقفل (App Lock):",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BrainBackground, RoundedCornerShape(10.dp))
                        .border(1.dp, BrainOutline, RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = BrainPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = "قفل التطبيق برمز PIN", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = if (isLockEnabled) "مفعّل حالياً" else "معطّل", fontSize = 11.sp, color = Color(0xFF64748B))
                        }
                    }
                    Switch(
                        checked = isLockEnabled,
                        onCheckedChange = { enabled ->
                            if (enabled) {
                                showPinInput = true
                            } else {
                                onDisableLock()
                                isLockEnabled = false
                                Toast.makeText(context, "تم إلغاء قفل التطبيق", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }

                if (showPinInput) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4) pinInput = it },
                        label = { Text("أدخل رمز PIN جديد (4 أرقام)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = {
                            if (pinInput.length == 4) {
                                onEnableLock(pinInput)
                                isLockEnabled = true
                                showPinInput = false
                                pinInput = ""
                                Toast.makeText(context, "تم تفعيل القفل بنجاح!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "يجب أن يتكون رمز المرور من 4 أرقام", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrainPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("حفظ رمز المرور")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Section: AI Engine Status
                Text(
                    text = "محرك الذكاء الاصطناعي (Gemini 3.5 Flash):",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (hasGeminiKey) Color(0xFFF0FDF4) else Color(0xFFFEF3C7), RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (hasGeminiKey) Color(0xFF16A34A) else Color(0xFFD97706),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (hasGeminiKey) "محرك Gemini AI متصل ونشط" else "الوضع الذكي المحلي (الهجين)",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (hasGeminiKey) Color(0xFF166534) else Color(0xFFB45309)
                        )
                        Text(
                            text = if (hasGeminiKey) "يتم استخراج النبذات والـ OCR آلياً بأعلى دقة" else "يعمل بنظام الاستخراج المحلي. يمكنك إضافة مفتاحك في لوحة Secrets",
                            fontSize = 11.sp,
                            color = Color(0xFF475569)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Section: Sync & Cloud Backup
                Text(
                    text = "المزامنة والنسخ السحابي (Firebase & Google):",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BrainBackground, RoundedCornerShape(10.dp))
                        .border(1.dp, BrainOutline, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CloudDone, contentDescription = null, tint = BrainSecondary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = "سحابة Firebase Firestore", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "مزامنة مشفرة لروابطك وتصنيفاتك لاستعادتها بأي وقت",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onSyncCloud,
                            colors = ButtonDefaults.buttonColors(containerColor = BrainSecondary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("مزامنة الآن", fontSize = 12.sp)
                        }

                        androidx.compose.material3.OutlinedButton(
                            onClick = onRestoreCloud,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("استعادة السحابة", fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // About Note
                Text(
                    text = "العقل الرقمي الثاني v1.0 • صُمم خصيصاً ليمنحك راحة البال وألا تضيع منك أي أداة أو فكرة تصادفها على الإنترنت أبداً.",
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = Color(0xFF94A3B8)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = BrainPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إغلاق")
            }
        },
        containerColor = BrainSurface,
        shape = RoundedCornerShape(16.dp)
    )
}
