package com.example.data.sync

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.model.BrainItem
import com.example.data.model.Category
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

sealed class SyncResult {
    data class Success(val uploadedCount: Int, val message: String) : SyncResult()
    data class Error(val errorMessage: String) : SyncResult()
}

sealed class RestoreResult {
    data class Success(val items: List<BrainItem>, val categories: List<Category>) : RestoreResult()
    data class Error(val errorMessage: String) : RestoreResult()
}

class FirestoreSyncManager(private val context: Context) {

    companion object {
        private const val TAG = "FirestoreSyncManager"
        private const val PREFS_NAME = "mind_vault_sync_prefs"
        private const val KEY_LAST_SYNC = "key_last_sync_timestamp"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    fun getCurrentUser(): FirebaseUser? = auth.currentUser

    fun getLastSyncTime(): Long = prefs.getLong(KEY_LAST_SYNC, 0L)

    private fun updateLastSyncTime(timestamp: Long = System.currentTimeMillis()) {
        prefs.edit().putLong(KEY_LAST_SYNC, timestamp).apply()
    }

    /**
     * Uploads local Room database records to Firebase Firestore.
     */
    suspend fun syncLocalToCloud(
        items: List<BrainItem>,
        categories: List<Category>
    ): SyncResult = withContext(Dispatchers.IO) {
        val user = auth.currentUser
        if (user == null) {
            return@withContext SyncResult.Error("يجب تسجيل الدخول أولاً بحساب Google للمزامنة السحابية")
        }

        try {
            val userDocRef = firestore.collection("users").document(user.uid)
            val itemsColRef = userDocRef.collection("brain_items")
            val categoriesColRef = userDocRef.collection("categories")

            // Batch or sequential write
            for (item in items) {
                val data = hashMapOf(
                    "id" to item.id,
                    "title" to item.title,
                    "summary" to item.summary,
                    "originalUrl" to (item.originalUrl ?: ""),
                    "notesRichText" to item.notesRichText,
                    "categoryId" to item.categoryId,
                    "tags" to item.tags,
                    "imageUri" to (item.imageUri ?: ""),
                    "ocrExtractedText" to item.ocrExtractedText,
                    "offlineArchiveContent" to item.offlineArchiveContent,
                    "reminderTimestamp" to (item.reminderTimestamp ?: 0L),
                    "isPinned" to item.isPinned,
                    "isLocked" to item.isLocked,
                    "isArchived" to item.isArchived,
                    "enrichmentStatus" to item.enrichmentStatus,
                    "createdAt" to item.createdAt,
                    "updatedAt" to item.updatedAt
                )
                itemsColRef.document(item.id).set(data, SetOptions.merge()).await()
            }

            for (cat in categories) {
                val catData = hashMapOf(
                    "id" to cat.id,
                    "nameArabic" to cat.nameArabic,
                    "iconKey" to cat.iconKey,
                    "colorHex" to cat.colorHex,
                    "isSystemDefault" to cat.isSystemDefault,
                    "isProtected" to cat.isProtected,
                    "sortOrder" to cat.sortOrder
                )
                categoriesColRef.document(cat.id).set(catData, SetOptions.merge()).await()
            }

            val now = System.currentTimeMillis()
            updateLastSyncTime(now)
            SyncResult.Success(items.size, "تمت مزامنة ${items.size} عنصر بنجاح إلى سحابة Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Sync to cloud failed", e)
            SyncResult.Error("فشلت المزامنة السحابية: ${e.localizedMessage ?: "خطأ غير معروف"}")
        }
    }

    /**
     * Restores items and custom categories from Firestore to the local database.
     */
    suspend fun restoreFromCloud(): RestoreResult = withContext(Dispatchers.IO) {
        val user = auth.currentUser
        if (user == null) {
            return@withContext RestoreResult.Error("يجب تسجيل الدخول بحساب Google لاستعادة البيانات")
        }

        try {
            val userDocRef = firestore.collection("users").document(user.uid)
            val itemsSnapshot = userDocRef.collection("brain_items").get().await()
            val categoriesSnapshot = userDocRef.collection("categories").get().await()

            val restoredItems = mutableListOf<BrainItem>()
            for (doc in itemsSnapshot.documents) {
                val id = doc.getString("id") ?: doc.id
                val title = doc.getString("title") ?: "بدون عنوان"
                val summary = doc.getString("summary") ?: ""
                val url = doc.getString("originalUrl")?.takeIf { it.isNotBlank() }
                val notes = doc.getString("notesRichText") ?: ""
                val catId = doc.getString("categoryId") ?: "ai_tools"
                @Suppress("UNCHECKED_CAST")
                val tags = (doc.get("tags") as? List<String>) ?: emptyList()
                val imageUri = doc.getString("imageUri")?.takeIf { it.isNotBlank() }
                val ocr = doc.getString("ocrExtractedText") ?: ""
                val offline = doc.getString("offlineArchiveContent") ?: ""
                val reminder = doc.getLong("reminderTimestamp")?.takeIf { it > 0 }
                val isPinned = doc.getBoolean("isPinned") ?: false
                val isLocked = doc.getBoolean("isLocked") ?: false
                val isArchived = doc.getBoolean("isArchived") ?: false
                val status = doc.getString("enrichmentStatus") ?: "READY"
                val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                val updatedAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()

                restoredItems.add(
                    BrainItem(
                        id = id,
                        title = title,
                        summary = summary,
                        originalUrl = url,
                        notesRichText = notes,
                        categoryId = catId,
                        tags = tags,
                        imageUri = imageUri,
                        ocrExtractedText = ocr,
                        offlineArchiveContent = offline,
                        reminderTimestamp = reminder,
                        isPinned = isPinned,
                        isLocked = isLocked,
                        isArchived = isArchived,
                        enrichmentStatus = status,
                        createdAt = createdAt,
                        updatedAt = updatedAt
                    )
                )
            }

            val restoredCategories = mutableListOf<Category>()
            for (doc in categoriesSnapshot.documents) {
                val id = doc.getString("id") ?: doc.id
                val name = doc.getString("nameArabic") ?: "تصنيف"
                val icon = doc.getString("iconKey") ?: "folder"
                val color = doc.getString("colorHex") ?: "#1E3A8A"
                val isDefault = doc.getBoolean("isSystemDefault") ?: false
                val isProtected = doc.getBoolean("isProtected") ?: false
                val order = doc.getLong("sortOrder")?.toInt() ?: 0

                restoredCategories.add(
                    Category(
                        id = id,
                        nameArabic = name,
                        iconKey = icon,
                        colorHex = color,
                        isSystemDefault = isDefault,
                        isProtected = isProtected,
                        sortOrder = order
                    )
                )
            }

            updateLastSyncTime()
            RestoreResult.Success(restoredItems, restoredCategories)
        } catch (e: Exception) {
            Log.e(TAG, "Restore from cloud failed", e)
            RestoreResult.Error("فشلت استعادة البيانات من السحابة: ${e.localizedMessage}")
        }
    }

    fun signOut() {
        auth.signOut()
    }
}
