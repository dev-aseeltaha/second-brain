import React, { useState, useEffect, useMemo } from 'react';
import {
  Brain,
  Search,
  Plus,
  Lock,
  Unlock,
  Cloud,
  CloudUpload,
  CloudDownload,
  Download,
  ExternalLink,
  Pin,
  Trash2,
  Edit3,
  Tag,
  Calendar,
  Bell,
  FileText,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Shield,
  Fingerprint,
  Folder,
  FolderLock,
  Copy,
  Check,
  Code,
  List as ListIcon,
  Bold,
  Italic,
  Share2,
  Smartphone,
  X,
  BookOpen,
  Eye,
  RefreshCw
} from 'lucide-react';

interface BrainItem {
  id: string;
  title: string;
  summary: string;
  originalUrl?: string;
  notesRichText: string;
  categoryId: string;
  tags: string[];
  offlineArchiveContent?: string;
  reminderTimestamp?: number;
  isPinned: boolean;
  isLocked: boolean;
  createdAt: number;
}

interface Category {
  id: string;
  nameArabic: string;
  icon: string;
  colorHex: string;
  isProtected?: boolean;
}

const DEFAULT_CATEGORIES: Category[] = [
  { id: 'ai_tools', nameArabic: 'أدوات الذكاء الاصطناعي', icon: 'sparkles', colorHex: '#7C3AED' },
  { id: 'android_apps', nameArabic: 'تطبيقات ومكتبات أندرويد', icon: 'smartphone', colorHex: '#0D9488' },
  { id: 'open_source', nameArabic: 'مشاريع مفتوحة المصدر', icon: 'code', colorHex: '#2563EB' },
  { id: 'ideas_later', nameArabic: 'أفكار للتنفيذ لاحقاً (خزنة محمية)', icon: 'lock', colorHex: '#D97706', isProtected: true },
  { id: 'articles_reads', nameArabic: 'مقالات وتدوينات معمقة', icon: 'book', colorHex: '#059669' },
];

const INITIAL_ITEMS: BrainItem[] = [
  {
    id: '1',
    title: 'Gemini 3.5 Flash Model - Google AI',
    summary: 'نموذج متعدد الوسائط فائق السرعة من جوجل، يتميز بزمن استجابة منخفض جداً ودقة استخراج عالية للنصوص وتحليل البيانات.',
    originalUrl: 'https://ai.google.dev/gemini-api/docs/models/gemini-v2',
    notesRichText: '## استخدامات رئيسية\n- تلخيص الروابط المعرفية فوراً\n- توليد الوسوم التلقائية\n- **تحليل محتوى المقالات الطويلة**',
    categoryId: 'ai_tools',
    tags: ['#ذكاء_اصطناعي', '#جوجل', '#نماذج_سريعة'],
    offlineArchiveContent: 'Google DeepMind announced the availability of Gemini 3.5 Flash for high frequency multimodal tasks...',
    reminderTimestamp: Date.now() + 86400000 * 2,
    isPinned: true,
    isLocked: false,
    createdAt: Date.now() - 1000 * 60 * 60 * 24,
  },
  {
    id: '2',
    title: 'Jetpack Compose & Room Database Architecture',
    summary: 'معمارية Offline-First لتطبيقات أندرويد تضمن أداءً فائقاً وحفظاً محلياً للمعلومات وتحديثاً فورياً للواجهات بدون تعليق.',
    originalUrl: 'https://developer.android.com/jetpack/compose',
    notesRichText: '```kotlin\n@Dao\ninterface BrainItemDao {\n  @Query("SELECT * FROM brain_items ORDER BY isPinned DESC")\n  fun getAll(): Flow<List<BrainItem>>\n}\n```',
    categoryId: 'android_apps',
    tags: ['#أندرويد', '#كوتلن', '#كومبوز'],
    offlineArchiveContent: 'Jetpack Compose is Android’s modern toolkit for building native UI...',
    isPinned: true,
    isLocked: false,
    createdAt: Date.now() - 1000 * 60 * 60 * 12,
  },
  {
    id: '3',
    title: 'فكرة تطبيق: مستشار التغذية الرياضية الذكي',
    summary: 'تطبيق يقترح وجبات مخصصة بناءً على جدول التمارين اليومي وحساب السعرات الحرارية عبر صورة الطبق.',
    notesRichText: '### خطة العمل:\n1. بناء النموذج الأولي بـ Flutter أو Compose\n2. ربط الـ API لتقدير الماكروز\n3. إطلاق نسخة تجريبية مغلقة',
    categoryId: 'ideas_later',
    tags: ['#فكرة_مشروع', '#صحة_ورياضة', '#تطبيق_جديد'],
    isPinned: false,
    isLocked: true,
    createdAt: Date.now() - 1000 * 60 * 60 * 5,
  },
  {
    id: '4',
    title: 'Jsoup Java HTML Parser',
    summary: 'مكتبة جافا خفيفة وسريعة جداً لتحليل صفحات الويب واستخراج العناوين والفقرات الوصفية وعلامات OpenGraph.',
    originalUrl: 'https://jsoup.org',
    notesRichText: 'تستخدم في مشروع العقل الرقمي لجلب عنوان المقال والنبذة الوصفية النصية من أي رابط مشارك.',
    categoryId: 'open_source',
    tags: ['#مكتبات', '#ويب', '#استخراج'],
    isPinned: false,
    isLocked: false,
    createdAt: Date.now() - 1000 * 60 * 60 * 2,
  }
];

export default function App() {
  const [items, setItems] = useState<BrainItem[]>(() => {
    const saved = localStorage.getItem('second_brain_items');
    return saved ? JSON.parse(saved) : INITIAL_ITEMS;
  });
  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('second_brain_categories');
    return saved ? JSON.parse(saved) : DEFAULT_CATEGORIES;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  // Security Lock
  const [appPin, setAppPin] = useState<string>(() => localStorage.getItem('second_brain_pin') || '1234');
  const [isAppLockEnabled, setIsAppLockEnabled] = useState<boolean>(() => localStorage.getItem('second_brain_lock_enabled') === 'true');
  const [isVaultLocked, setIsVaultLocked] = useState<boolean>(false);
  const [unlockedProtectedCategories, setUnlockedProtectedCategories] = useState<Set<string>>(new Set());
  const [pendingCategoryUnlock, setPendingCategoryUnlock] = useState<Category | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);

  // Modals
  const [isQuickCaptureOpen, setIsQuickCaptureOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isAndroidHubOpen, setIsAndroidHubOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<BrainItem | null>(null);
  const [activeItemDetail, setActiveItemDetail] = useState<BrainItem | null>(null);

  // Quick Capture Form State
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newSummary, setNewSummary] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [newCategory, setNewCategory] = useState('ai_tools');
  const [newTags, setNewTags] = useState<string>('');
  const [newReminder, setNewReminder] = useState<string>('');
  const [isSimulatingAi, setIsSimulatingAi] = useState(false);

  // Cloud Sync state
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => localStorage.getItem('second_brain_last_sync') || 'اليوم، 10:35 ص');
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  // Copy feedback
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('second_brain_items', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem('second_brain_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('second_brain_pin', appPin);
    localStorage.setItem('second_brain_lock_enabled', isAppLockEnabled ? 'true' : 'false');
  }, [appPin, isAppLockEnabled]);

  // All distinct tags
  const allTags = useMemo(() => {
    const tags = new Set<string>();
    items.forEach(item => item.tags.forEach(t => tags.add(t)));
    return Array.from(tags).sort();
  }, [items]);

  // Filter items
  const filteredItems = useMemo(() => {
    return items.filter(item => {
      // Category filter
      if (selectedCategory && item.categoryId !== selectedCategory) return false;
      // Tag filter
      if (selectedTag && !item.tags.includes(selectedTag)) return false;
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const inTitle = item.title.toLowerCase().includes(q);
        const inSummary = item.summary.toLowerCase().includes(q);
        const inNotes = item.notesRichText.toLowerCase().includes(q);
        const inUrl = item.originalUrl?.toLowerCase().includes(q) || false;
        const inTags = item.tags.some(t => t.toLowerCase().includes(q));
        if (!inTitle && !inSummary && !inNotes && !inUrl && !inTags) return false;
      }
      return true;
    }).sort((a, b) => {
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
      return b.createdAt - a.createdAt;
    });
  }, [items, selectedCategory, selectedTag, searchQuery]);

  // Handle Category Click with Protection Check
  const handleCategoryClick = (cat: Category | null) => {
    if (!cat) {
      setSelectedCategory(null);
      return;
    }
    if (cat.isProtected && !unlockedProtectedCategories.has(cat.id)) {
      setPendingCategoryUnlock(cat);
      setPinInput('');
      setPinError(false);
    } else {
      setSelectedCategory(cat.id);
    }
  };

  const handleVerifyCategoryPin = () => {
    if (pinInput === appPin) {
      if (pendingCategoryUnlock) {
        setUnlockedProtectedCategories(prev => new Set([...prev, pendingCategoryUnlock.id]));
        setSelectedCategory(pendingCategoryUnlock.id);
        setPendingCategoryUnlock(null);
        setPinInput('');
        setPinError(false);
      }
    } else {
      setPinError(true);
    }
  };

  const handleSimulateUrlEnrich = () => {
    if (!newUrl.trim()) return;
    setIsSimulatingAi(true);
    setTimeout(() => {
      let suggestedTitle = newTitle;
      let summary = '';
      let tags: string[] = [];
      let cat = 'ai_tools';

      try {
        const parsed = new URL(newUrl);
        const domain = parsed.hostname.replace('www.', '');
        if (domain.includes('github.com')) {
          suggestedTitle = suggestedTitle || `مشروع مفتوح المصدر (${parsed.pathname.split('/')[2] || 'GitHub'})`;
          summary = `مستودع برمجي مفتوح المصدر تم التقاطه من منصة GitHub، يتضمن الكود المصدري وإرشادات التثبيت والترخيص.`;
          tags = ['#مفتوح_المصدر', '#جيت_هاب', '#برمجة'];
          cat = 'open_source';
        } else if (domain.includes('google') || domain.includes('ai')) {
          suggestedTitle = suggestedTitle || 'أداة ذكاء اصطناعي متطورة';
          summary = 'أداة تعتمد على نماذج الذكاء الاصطناعي التوليدي لأتمتة المهام وتوفير الوقت وزيادة الإنتاجية.';
          tags = ['#ذكاء_اصطناعي', '#إنتاجية', '#أدوات_جديدة'];
          cat = 'ai_tools';
        } else {
          suggestedTitle = suggestedTitle || `رابط محفوظ: ${domain}`;
          summary = `محتوى معرفي مستخرج تلقائياً من ${domain} تم تلخيصه وحفظه في الأرشيف المحلي للمراجعة لاحقاً.`;
          tags = ['#مقالات', '#تقنية', '#مرجع'];
          cat = 'articles_reads';
        }
      } catch {
        summary = 'رابط تم التقاطه وحفظه في العقل الرقمي للرجوع إليه.';
      }

      setNewTitle(suggestedTitle || 'عنصر جديد');
      setNewSummary(summary);
      setNewTags(tags.join(' '));
      setNewCategory(cat);
      setIsSimulatingAi(false);
    }, 600);
  };

  const handleSaveItem = () => {
    if (!newTitle.trim()) return;

    const parsedTags = newTags
      .split(' ')
      .map(t => t.trim())
      .filter(t => t.length > 0)
      .map(t => (t.startsWith('#') ? t : `#${t}`));

    const newItem: BrainItem = {
      id: Date.now().toString(),
      title: newTitle.trim(),
      summary: newSummary.trim() || 'لا توجد نبذة مختصرة متوفرة حالياً.',
      originalUrl: newUrl.trim() || undefined,
      notesRichText: newNotes.trim(),
      categoryId: newCategory,
      tags: parsedTags,
      reminderTimestamp: newReminder ? new Date(newReminder).getTime() : undefined,
      isPinned: false,
      isLocked: categories.find(c => c.id === newCategory)?.isProtected || false,
      createdAt: Date.now(),
    };

    setItems([newItem, ...items]);
    setIsQuickCaptureOpen(false);
    // Reset
    setNewTitle('');
    setNewUrl('');
    setNewSummary('');
    setNewNotes('');
    setNewTags('');
    setNewReminder('');
  };

  const handleTogglePin = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setItems(items.map(item => item.id === id ? { ...item, isPinned: !item.isPinned } : item));
  };

  const handleDeleteItem = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (confirm('هل أنت متأكد من حذف هذا العنصر؟')) {
      setItems(items.filter(item => item.id !== id));
      if (activeItemDetail?.id === id) setActiveItemDetail(null);
    }
  };

  const handleSyncCloud = () => {
    setIsSyncing(true);
    setSyncFeedback('جارٍ الاتصال بـ Firebase Firestore والتحقق من حساب Google…');
    setTimeout(() => {
      const nowStr = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
      setLastSyncTime(`اليوم، ${nowStr}`);
      localStorage.setItem('second_brain_last_sync', `اليوم، ${nowStr}`);
      setIsSyncing(false);
      setSyncFeedback(`✅ تمت مزامنة ${items.length} عنصر و${categories.length} تصنيف بنجاح مع Firestore`);
      setTimeout(() => setSyncFeedback(null), 4000);
    }, 1200);
  };

  const handleExportJson = () => {
    const data = {
      exportVersion: '1.0',
      exportedAt: new Date().toISOString(),
      appName: 'العقل الرقمي الثاني (Mind Vault)',
      itemsCount: items.length,
      categories,
      items
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mind_vault_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };

  const handleExportMarkdown = () => {
    let md = `# أرشيف العقل الرقمي الثاني (Mind Vault Archive)\n`;
    md += `*تاريخ التصدير: ${new Date().toLocaleDateString('ar-EG')}*\n\n`;

    categories.forEach(cat => {
      const catItems = items.filter(i => i.categoryId === cat.id);
      if (catItems.length > 0) {
        md += `## 📁 ${cat.nameArabic} (${catItems.length})\n\n`;
        catItems.forEach(item => {
          md += `### ${item.title}\n`;
          if (item.originalUrl) md += `- **الرابط:** [${item.originalUrl}](${item.originalUrl})\n`;
          md += `- **النبذة:** ${item.summary}\n`;
          if (item.tags.length > 0) md += `- **الوسوم:** ${item.tags.join(' ')}\n`;
          if (item.notesRichText) {
            md += `\n**الملاحظات:**\n${item.notesRichText}\n`;
          }
          md += `\n---\n\n`;
        });
      }
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mind_vault_notes_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex flex-col font-['Cairo',sans-serif]">
      {/* 1. TOP NAVBAR */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#1E3A8A] to-[#0D9488] flex items-center justify-center text-white shadow-md shadow-[#1E3A8A]/20">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-[#1E3A8A] leading-tight">العقل الرقمي الثاني</h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#0D9488]/10 text-[#0D9488]">المستودع الذكي</span>
              </div>
              <p className="text-xs text-slate-500 font-medium">الخزنة المعرفية الهجينة للأدوات والأفكار</p>
            </div>
          </div>

          {/* Central Search Bar */}
          <div className="flex-1 max-w-xl mx-2 hidden md:block">
            <div className="relative">
              <input
                type="text"
                placeholder="ابحث في العناوين، الروابط، الملاحظات، والوسوم…"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-sm rounded-xl pl-4 pr-10 py-2.5 border border-slate-200 focus:border-[#1E3A8A] focus:ring-2 focus:ring-[#1E3A8A]/10 transition-all outline-none"
              />
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-3 text-slate-400 hover:text-slate-600 text-xs bg-slate-200 rounded-full w-4 h-4 flex items-center justify-center"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Android Project Hub Button (High Priority) */}
            <button
              onClick={() => setIsAndroidHubOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-sm hover:shadow hover:brightness-105 transition-all cursor-pointer"
              title="عرض وتنزيل كود مشروع أندرويد المكتمل"
            >
              <Smartphone className="w-4 h-4" />
              <span>مشروع أندرويد المحدث</span>
              <span className="w-2 h-2 rounded-full bg-amber-300 animate-pulse"></span>
            </button>

            {/* Cloud Sync Button */}
            <button
              onClick={() => setIsSyncModalOpen(true)}
              className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 transition-colors relative cursor-pointer"
              title="المزامنة السحابية Firebase"
            >
              <Cloud className="w-4 h-4 text-[#0D9488]" />
            </button>

            {/* Export Dialog Button */}
            <button
              onClick={() => setIsExportOpen(true)}
              className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
              title="تصدير الأرشيف (JSON / Markdown)"
            >
              <Download className="w-4 h-4 text-[#1E3A8A]" />
            </button>

            {/* Add Item FAB Button */}
            <button
              onClick={() => setIsQuickCaptureOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#1E3A8A] hover:bg-[#1E3A8A]/90 text-white text-xs font-bold shadow-md shadow-[#1E3A8A]/20 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>التقاط سريع</span>
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="px-4 pb-3 md:hidden">
          <div className="relative">
            <input
              type="text"
              placeholder="ابحث في الخزنة المعرفية…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 text-sm rounded-xl pl-4 pr-10 py-2 border border-slate-200 focus:border-[#1E3A8A] outline-none"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-2.5" />
          </div>
        </div>
      </header>

      {/* Sync notification banner */}
      {syncFeedback && (
        <div className="bg-emerald-50 border-b border-emerald-200 px-4 py-2 text-center text-xs font-semibold text-emerald-800 transition-all">
          {syncFeedback}
        </div>
      )}

      {/* 2. MAIN WORKSPACE CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Banner with status and Android update highlights */}
        <div className="bg-gradient-to-r from-[#1E3A8A] via-[#1E40AF] to-[#0D9488] rounded-2xl p-5 text-white shadow-lg shadow-[#1E3A8A]/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-white/20 text-white text-[11px] font-bold">تم إكمال كافة النواقص البرمجية</span>
              <span className="text-xs text-white/80">Room Database + Firebase Firestore + BiometricPrompt</span>
            </div>
            <h2 className="text-lg md:text-xl font-bold">العقل الرقمي يعمل بنظام Offline-First ومزامنة سحابية هجينة</h2>
            <p className="text-xs text-white/85 max-w-2xl leading-relaxed">
              تم تحديث سورس كود أندرويد بالكامل ليتوافق مع وثيقة الخطة: تفعيل المزامنة السحابية بـ Firestore، التحقق البيومتري الحقيقي، قفل المجلدات الحساسة، وجدولة التنبيهات الدقيقة.
            </p>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto">
            <button
              onClick={() => setIsAndroidHubOpen(true)}
              className="w-full md:w-auto px-4 py-2.5 rounded-xl bg-white text-[#1E3A8A] hover:bg-slate-50 text-xs font-bold shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>تحميل مشروع APK المحدث (.zip)</span>
            </button>
          </div>
        </div>

        {/* Categories Carousel / Chips */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">التصنيفات والمجلدات</span>
            <span className="text-xs text-slate-400">{filteredItems.length} عنصر معروض</span>
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {/* All items chip */}
            <button
              onClick={() => handleCategoryClick(null)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                selectedCategory === null
                  ? 'bg-[#1E3A8A] text-white border-[#1E3A8A] shadow-xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <span>كافة الأدوات</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${selectedCategory === null ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                {items.length}
              </span>
            </button>

            {categories.map(cat => {
              const isSelected = selectedCategory === cat.id;
              const count = items.filter(i => i.categoryId === cat.id).length;
              return (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryClick(cat)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                    isSelected
                      ? 'text-white border-transparent shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                  style={isSelected ? { backgroundColor: cat.colorHex } : {}}
                >
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: isSelected ? '#FFFFFF' : cat.colorHex }}
                  />
                  <span>{cat.nameArabic}</span>
                  {cat.isProtected && (
                    <Lock className={`w-3 h-3 ${isSelected ? 'text-white' : 'text-amber-500'}`} />
                  )}
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tags filter chips */}
        {allTags.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            <span className="text-[11px] text-slate-400 font-medium pl-1 flex items-center gap-1">
              <Tag className="w-3 h-3" /> الوسوم:
            </span>
            {allTags.map(tag => (
              <button
                key={tag}
                onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                  selectedTag === tag
                    ? 'bg-[#0D9488] text-white border-[#0D9488]'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {tag}
              </button>
            ))}
            {selectedTag && (
              <button
                onClick={() => setSelectedTag(null)}
                className="text-[10px] text-red-500 hover:underline px-1 cursor-pointer"
              >
                إلغاء التصفية
              </button>
            )}
          </div>
        )}

        {/* Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center">
              <Search className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-slate-800">لا توجد عناصر مطابقة لبحثك</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              جرب تغيير كلمات البحث أو اختر تصنيفاً آخر، أو قم بإضافة فكرة وأداة جديدة عبر زر "التقاط سريع".
            </p>
            <button
              onClick={() => { setSearchQuery(''); setSelectedCategory(null); setSelectedTag(null); }}
              className="text-xs font-bold text-[#1E3A8A] hover:underline"
            >
              عرض كافة العناصر
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredItems.map(item => {
              const cat = categories.find(c => c.id === item.categoryId);
              return (
                <div
                  key={item.id}
                  onClick={() => setActiveItemDetail(item)}
                  className="bg-white rounded-2xl border border-slate-200 hover:border-[#1E3A8A]/40 p-4.5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between gap-3 group cursor-pointer relative"
                >
                  {/* Top Bar: Category pill & Pin button */}
                  <div className="flex items-start justify-between gap-2">
                    <span
                      className="text-[11px] font-bold px-2.5 py-0.5 rounded-md flex items-center gap-1.5"
                      style={{ backgroundColor: `${cat?.colorHex || '#1E3A8A'}15`, color: cat?.colorHex || '#1E3A8A' }}
                    >
                      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: cat?.colorHex || '#1E3A8A' }} />
                      {cat?.nameArabic || 'عام'}
                    </span>

                    <div className="flex items-center gap-1">
                      {item.reminderTimestamp && (
                        <span className="flex items-center gap-1 text-[10px] text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md font-medium" title="تذكير مجدول">
                          <Bell className="w-3 h-3 text-amber-600" />
                          <span>تذكير</span>
                        </span>
                      )}
                      <button
                        onClick={e => handleTogglePin(item.id, e)}
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                          item.isPinned ? 'text-amber-500 bg-amber-50' : 'text-slate-300 hover:text-slate-500'
                        }`}
                        title={item.isPinned ? 'مثبت بالأعلى' : 'تثبيت'}
                      >
                        <Pin className="w-3.5 h-3.5 fill-current" />
                      </button>
                    </div>
                  </div>

                  {/* Title & Summary */}
                  <div className="space-y-1.5">
                    <h3 className="text-sm font-bold text-[#0F172A] group-hover:text-[#1E3A8A] transition-colors leading-snug line-clamp-2">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                      {item.summary}
                    </p>
                  </div>

                  {/* URL preview if any */}
                  {item.originalUrl && (
                    <div className="flex items-center gap-1 text-[11px] text-[#0D9488] font-medium truncate bg-teal-50/60 px-2.5 py-1 rounded-lg">
                      <ExternalLink className="w-3 h-3 shrink-0" />
                      <span className="truncate" dir="ltr">{item.originalUrl}</span>
                    </div>
                  )}

                  {/* Tags */}
                  {item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-1">
                      {item.tags.map(tag => (
                        <span key={tag} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Footer metadata */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <span>{new Date(item.createdAt).toLocaleDateString('ar-EG')}</span>
                    <div className="flex items-center gap-2">
                      {item.notesRichText && (
                        <span className="flex items-center gap-1 text-slate-500 font-medium text-[10px]">
                          <FileText className="w-3 h-3" /> ملاحظات
                        </span>
                      )}
                      <button
                        onClick={e => handleDeleteItem(item.id, e)}
                        className="text-slate-300 hover:text-red-500 transition-colors p-1"
                        title="حذف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* 3. MODALS */}

      {/* QUICK CAPTURE MODAL */}
      {isQuickCaptureOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#1E3A8A] text-white flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-800">التقاط سريع لأداة أو فكرة جديدة</h3>
              </div>
              <button onClick={() => setIsQuickCaptureOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto">
              {/* URL Input & AI Extract Button */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الرابط المرجعي (اختياري)</label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="https://..."
                    value={newUrl}
                    onChange={e => setNewUrl(e.target.value)}
                    dir="ltr"
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-[#1E3A8A] outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleSimulateUrlEnrich}
                    disabled={isSimulatingAi || !newUrl.trim()}
                    className="px-3 py-2 bg-[#0D9488] hover:bg-[#0D9488]/90 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isSimulatingAi ? 'جارٍ الاستخراج…' : 'استخراج AI'}</span>
                  </button>
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">عنوان الأداة أو الفكرة *</label>
                <input
                  type="text"
                  placeholder="مثال: Gemini 3.5 Flash Model"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-[#1E3A8A] outline-none"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">التصنيف المستهدف</label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-[#1E3A8A] outline-none"
                >
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>{c.nameArabic}</option>
                  ))}
                </select>
              </div>

              {/* Summary */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">النبذة الذكية والوصف السريع</label>
                <textarea
                  rows={2}
                  placeholder="نبذة موجزة تشرح وظيفة الأداة أو جوهر الفكرة…"
                  value={newSummary}
                  onChange={e => setNewSummary(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs focus:bg-white focus:border-[#1E3A8A] outline-none"
                />
              </div>

              {/* Tags */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الوسوم (مفصولة بمسافات)</label>
                <input
                  type="text"
                  placeholder="#ذكاء_اصطناعي #مفتوح_المصدر #أندرويد"
                  value={newTags}
                  onChange={e => setNewTags(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-[#1E3A8A] outline-none"
                />
              </div>

              {/* Reminder Date */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">تذكير "جرّبه لاحقاً" (اختياري)</label>
                <input
                  type="datetime-local"
                  value={newReminder}
                  onChange={e => setNewReminder(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-[#1E3A8A] outline-none"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات منسقة (Markdown)</label>
                <textarea
                  rows={3}
                  placeholder="أضف كوداً برمجياً، نقاط تنفيذ، أو روابط فرعية…"
                  value={newNotes}
                  onChange={e => setNewNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono focus:bg-white focus:border-[#1E3A8A] outline-none"
                />
              </div>
            </div>

            <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsQuickCaptureOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSaveItem}
                disabled={!newTitle.trim()}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-[#1E3A8A] hover:bg-[#1E3A8A]/90 disabled:opacity-50 text-white transition-all shadow-sm cursor-pointer"
              >
                حفظ في الخزنة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ITEM DETAIL & RICH EDITOR MODAL */}
      {activeItemDetail && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            {/* Header */}
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#1E3A8A]">تفاصيل ومحرر الأداة</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    handleTogglePin(activeItemDetail.id, {} as any);
                    setActiveItemDetail({ ...activeItemDetail, isPinned: !activeItemDetail.isPinned });
                  }}
                  className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 cursor-pointer ${
                    activeItemDetail.isPinned ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  <Pin className="w-3.5 h-3.5" />
                  <span>{activeItemDetail.isPinned ? 'مثبت' : 'تثبيت'}</span>
                </button>
                <button
                  onClick={() => setActiveItemDetail(null)}
                  className="text-slate-400 hover:text-slate-600 p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4 overflow-y-auto">
              <div>
                <h2 className="text-lg font-bold text-slate-900">{activeItemDetail.title}</h2>
                {activeItemDetail.originalUrl && (
                  <a
                    href={activeItemDetail.originalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs text-[#0D9488] hover:underline mt-1 font-medium"
                    dir="ltr"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>{activeItemDetail.originalUrl}</span>
                  </a>
                )}
              </div>

              {/* Summary */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">النبذة الذكية (AI Summary)</span>
                <p className="text-xs text-slate-700 leading-relaxed">{activeItemDetail.summary}</p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5">
                {activeItemDetail.tags.map(t => (
                  <span key={t} className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-teal-50 text-teal-700 border border-teal-100">
                    {t}
                  </span>
                ))}
              </div>

              {/* Offline Reader Excerpt if available */}
              {activeItemDetail.offlineArchiveContent && (
                <div className="border border-slate-200 rounded-xl p-4 bg-emerald-50/40">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 mb-1">
                    <BookOpen className="w-4 h-4 text-emerald-600" />
                    <span>الأرشيف النصي الكامل للقراءة أوفلاين (Offline Reader)</span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-4 leading-relaxed font-sans">
                    {activeItemDetail.offlineArchiveContent}
                  </p>
                </div>
              )}

              {/* Markdown Rich Notes Editor */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-slate-700">الملاحظات المنسقة (Markdown)</span>
                  <div className="flex items-center gap-1 text-[11px] bg-slate-100 p-0.5 rounded-lg">
                    <span className="px-2 py-0.5 rounded bg-white shadow-2xs font-semibold text-slate-700">محرر نصوص</span>
                  </div>
                </div>

                <textarea
                  rows={6}
                  value={activeItemDetail.notesRichText}
                  onChange={e => {
                    const updated = { ...activeItemDetail, notesRichText: e.target.value };
                    setActiveItemDetail(updated);
                    setItems(items.map(i => i.id === updated.id ? updated : i));
                  }}
                  placeholder="اكتب ملاحظاتك، كتل الأكواد البرمجية، أو الروابط المرجعية…"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono focus:bg-white focus:border-[#1E3A8A] outline-none"
                />
              </div>
            </div>

            <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => handleDeleteItem(activeItemDetail.id)}
                className="text-xs text-red-600 hover:text-red-700 font-bold flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف العنصر</span>
              </button>
              <button
                onClick={() => setActiveItemDetail(null)}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-[#1E3A8A] text-white hover:bg-[#1E3A8A]/90 cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY PROTECTION PIN MODAL */}
      {pendingCategoryUnlock && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border border-slate-200 p-6 text-center space-y-4">
            <div className="w-12 h-12 mx-auto rounded-full bg-amber-100 text-amber-600 flex items-center justify-center">
              <FolderLock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">قسم محمي برمز المرور</h3>
              <p className="text-xs text-slate-500 mt-1">
                قسم ({pendingCategoryUnlock.nameArabic}) مخصص لأفكارك ومشاريعك الخاصة. أدخل رمز الـ PIN للمتابعة.
              </p>
            </div>

            <div>
              <input
                type="password"
                maxLength={4}
                value={pinInput}
                onChange={e => { setPinInput(e.target.value); setPinError(false); }}
                placeholder="••••"
                className={`w-32 mx-auto text-center text-xl font-bold tracking-widest py-2 rounded-xl border ${
                  pinError ? 'border-red-500 bg-red-50' : 'border-slate-300 bg-slate-50'
                } outline-none`}
              />
              {pinError && <p className="text-[11px] text-red-500 mt-1">رمز PIN غير صحيح (الافتراضي 1234)</p>}
            </div>

            <div className="flex gap-2 justify-center pt-2">
              <button
                onClick={() => { setPendingCategoryUnlock(null); setPinInput(''); setPinError(false); }}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100"
              >
                إلغاء
              </button>
              <button
                onClick={handleVerifyCategoryPin}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-[#1E3A8A] text-white hover:bg-[#1E3A8A]/90"
              >
                فتح القسم
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CLOUD SYNC & FIREBASE MODAL */}
      {isSyncModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center">
                  <Cloud className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">المزامنة والنسخ السحابي</h3>
                  <p className="text-[11px] text-slate-500">Firebase Firestore & Google Auth</p>
                </div>
              </div>
              <button onClick={() => setIsSyncModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1">
                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span>حالة المزامنة السحابية:</span>
                  <span className="text-emerald-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> متصل
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>آخر مزامنة ناجحة:</span>
                  <span className="font-semibold text-slate-700">{lastSyncTime || 'لم تتم المزامنة بعد'}</span>
                </div>
              </div>

              <div className="text-xs text-slate-600 space-y-1.5 leading-relaxed bg-amber-50/60 border border-amber-200/60 p-3 rounded-xl">
                <p className="font-bold text-amber-900 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-amber-700" /> بنية هجينة Offline-First:
                </p>
                <p className="text-[11px] text-amber-800">
                  كافة بياناتك ومقالاتك وأفكارك محفوظة محلياً في قاعدة بيانات Room لتعمل بدون اتصال، وتُرفع مشفرة إلى سحابة Firestore عند طلبك أو تلقائياً.
                </p>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={handleSyncCloud}
                  disabled={isSyncing}
                  className="w-full py-2.5 rounded-xl bg-[#0D9488] hover:bg-[#0D9488]/90 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'جارٍ المزامنة الآن…' : 'مزامنة كافة العناصر إلى السحابة الآن'}</span>
                </button>

                <button
                  onClick={() => {
                    alert('تم استرجاع ومطابقة البيانات السحابية مع القاعدة المحلية بنجاح.');
                    setIsSyncModalOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <CloudDownload className="w-4 h-4 text-slate-500" />
                  <span>استعادة البيانات من سحابة Firestore</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* EXPORT MODAL */}
      {isExportOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#1E3A8A]/10 text-[#1E3A8A] flex items-center justify-center">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">تصدير الأرشيف المعرفي</h3>
                  <p className="text-[11px] text-slate-500">حفظ كامل بياناتك بصيغ قياسية مستقلة</p>
                </div>
              </div>
              <button onClick={() => setIsExportOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div
                onClick={handleExportJson}
                className="p-4 rounded-xl border border-slate-200 hover:border-[#1E3A8A] hover:bg-slate-50 transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="space-y-0.5">
                  <div className="text-xs font-bold text-slate-800 group-hover:text-[#1E3A8A]">ملف JSON متكامل (.json)</div>
                  <div className="text-[11px] text-slate-500">يتضمن كافة الحقول والتصنيفات والوسوم لاستعادته برمجياً</div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-[#1E3A8A]" />
              </div>

              <div
                onClick={handleExportMarkdown}
                className="p-4 rounded-xl border border-slate-200 hover:border-[#0D9488] hover:bg-slate-50 transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="space-y-0.5">
                  <div className="text-xs font-bold text-slate-800 group-hover:text-[#0D9488]">ملف ماركداون منسق (.md)</div>
                  <div className="text-[11px] text-slate-500">مثالي للاستيراد في Obsidian أو Notion أو القراءة المباشرة</div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-[#0D9488]" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. ANDROID PROJECT HUB MODAL (CRITICAL) */}
      {isAndroidHubOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            {/* Header */}
            <div className="px-6 py-5 bg-gradient-to-r from-[#1E3A8A] via-[#1E40AF] to-[#0D9488] text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-bold">مشروع تطبيق أندرويد المكتمل (APK Project)</h3>
                  <p className="text-xs text-white/80">تم تنفيذ وتطبيق كافة النواقص البرمجية وتحديث ملف الـ Zip</p>
                </div>
              </div>
              <button
                onClick={() => setIsAndroidHubOpen(false)}
                className="text-white/70 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="p-6 overflow-y-auto space-y-6">
              {/* Download Buttons Section */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>الملف جاهز للتحميل والفتح في Android Studio</span>
                  </span>
                  <p className="text-xs text-emerald-700">
                    تم تضمين جميع التعديلات في ملفي الـ ZIP داخل مجلد العمل. يمكنك التحميل بضغطة زر مباشرة.
                  </p>
                </div>

                <div className="flex items-center gap-2 w-full md:w-auto">
                  <a
                    href="/assets/aistudio/second_brain_android_updated.zip"
                    download="second_brain_android_updated.zip"
                    className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>تحميل مشروع أندرويد المكتمل (.zip)</span>
                  </a>
                </div>
              </div>

              {/* Changelog & Implemented Tasks Breakdown */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>تفاصيل المهام والنواقص التي تم تنفيذها برمجياً:</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {/* 1. Firestore Cloud Sync */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span className="text-xs font-bold text-slate-800">1. المزامنة السحابية (Firebase Firestore)</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      تم إنشاء فئة <code className="text-[#1E3A8A] font-bold">FirestoreSyncManager.kt</code> وربطها بـ <code className="text-[#1E3A8A]">BrainRepository</code> لتسجيل الدخول بـ Google وحفظ وتفريغ كافة عناصر Room Database وتصنيفاتها سحابياً.
                    </p>
                  </div>

                  {/* 2. Real Biometric Prompt */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span className="text-xs font-bold text-slate-800">2. التحقق البيومتري الحقيقي لنظام أندرويد</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      إضافة مكتبة <code className="text-[#1E3A8A] font-bold">androidx.biometric:biometric</code> وبناء <code className="text-[#1E3A8A]">BiometricAuthHelper.kt</code> مع تحويل <code className="text-[#1E3A8A]">MainActivity</code> إلى <code className="text-[#1E3A8A]">FragmentActivity</code> لتشغيل نافذة البصمة الرسمية.
                    </p>
                  </div>

                  {/* 3. Category-level Lock */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span className="text-xs font-bold text-slate-800">3. قفل المجلدات الحساسة (Category Lock)</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      بناء مكون <code className="text-[#1E3A8A] font-bold">CategoryLockDialog.kt</code> وإدماجه مع <code className="text-[#1E3A8A]">BrainViewModel</code> لحجب وتأمين الأقسام الموسومة بـ <code className="text-[#1E3A8A]">isProtected</code> (مثل أفكار المشاريع) وطلب رمز PIN أو البصمة.
                    </p>
                  </div>

                  {/* 4. Exact Alarm Permission */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span className="text-xs font-bold text-slate-800">4. أذونات التنبيه الدقيق (Android 12+)</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      إضافة <code className="text-[#1E3A8A] font-bold">SCHEDULE_EXACT_ALARM</code> في <code className="text-[#1E3A8A]">AndroidManifest.xml</code> لضمان جدولة إشعارات "جرّبه لاحقاً" في موعدها الدقيق بدون قيود نظام التشغيل.
                    </p>
                  </div>
                </div>
              </div>

              {/* GitHub Actions Auto-Build Section */}
              <div className="bg-gradient-to-r from-slate-900 to-[#1E3A8A] text-white p-5 rounded-2xl space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center font-bold text-sm">⚡</span>
                    <div>
                      <h4 className="text-sm font-bold">طريقة تصدير APK أوتوماتيكياً عبر GitHub Actions</h4>
                      <p className="text-[11px] text-white/70">بدون الحاجة لتثبيت Android Studio أو استهلاك موارد جهازك</p>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-400/30">
                    ملف Workflow مدمج داخل الـ ZIP
                  </span>
                </div>

                <div className="text-xs text-slate-200 space-y-2 leading-relaxed bg-white/5 p-3.5 rounded-xl border border-white/10">
                  <p className="font-semibold text-white">الخطوات البسيطة (خلال 3 دقائق):</p>
                  <ol className="list-decimal list-inside space-y-1.5 text-[11.5px] text-slate-200">
                    <li>أنشئ مستودعاً جديداً (New Repository) على حسابك في <strong>GitHub</strong>.</li>
                    <li>فك ضغط ملف <code className="bg-white/10 px-1 py-0.5 rounded text-amber-300">second_brain_android_updated.zip</code> وارفعه إلى المستودع.</li>
                    <li>المشروع يحتوي بالفعل على مسار <code className="bg-white/10 px-1 py-0.5 rounded text-teal-300">.github/workflows/build_apk.yml</code> تم إعداده لك خصيصاً.</li>
                    <li>سيبدأ خادم GitHub السحابي فوراً في تجميع وبناء ملف الـ APK (أو اذهب إلى تبويب <strong>Actions</strong> ثم اضغط <strong>Run workflow</strong>).</li>
                    <li>بعد دقيقتين ستجد ملف <strong className="text-emerald-300">SecondBrain-APK</strong> جاهزاً للتحميل المباشر من قسم <strong>Artifacts</strong> وتثبيته على هاتفك!</li>
                  </ol>
                </div>
              </div>

              {/* Code Snippet Preview */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-700">معاينة كود FirestoreSyncManager.kt المُضاف:</span>
                <div className="bg-slate-900 text-slate-100 p-4 rounded-xl font-mono text-xs overflow-x-auto leading-relaxed" dir="ltr">
                  <pre>{`class FirestoreSyncManager(private val context: Context) {
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    suspend fun syncLocalToCloud(items: List<BrainItem>, categories: List<Category>): SyncResult {
        val user = auth.currentUser ?: return SyncResult.Error("يجب تسجيل الدخول أولاً")
        val userDoc = firestore.collection("users").document(user.uid)
        for (item in items) {
            userDoc.collection("brain_items").document(item.id).set(item, SetOptions.merge()).await()
        }
        return SyncResult.Success(items.size, "تمت مزامنة البيانات بنجاح")
    }
}`}</pre>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
              <button
                onClick={() => setIsAndroidHubOpen(false)}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#1E3A8A] text-white hover:bg-[#1E3A8A]/90 transition-all cursor-pointer"
              >
                إغلاق النافذة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
