import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Brain,
  Search,
  Plus,
  Lock,
  Unlock,
  Cloud,
  CloudUpload,
  CloudDownload,
  Download,
  ExternalLink,
  Pin,
  Trash2,
  Edit3,
  Tag,
  Calendar,
  Bell,
  FileText,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Shield,
  Fingerprint,
  Folder,
  FolderLock,
  Copy,
  Check,
  Code,
  LayoutGrid,
  List as ListIcon,
  Bold,
  Italic,
  Share2,
  Smartphone,
  X,
  BookOpen,
  Eye,
  RefreshCw,
  Image as ImageIcon,
  Upload,
  ArrowUpDown,
  Filter
} from 'lucide-react';

interface BrainItem {
  id: string;
  title: string;
  summary: string;
  originalUrl?: string;
  notesRichText: string;
  categoryId: string;
  tags: string[];
  imageUri?: string;
  ocrExtractedText?: string;
  offlineArchiveContent?: string;
  reminderTimestamp?: number;
  isPinned: boolean;
  isLocked: boolean;
  createdAt: number;
}

interface Category {
  id: string;
  nameArabic: string;
  icon: string;
  colorHex: string;
  isProtected?: boolean;
}

// 1. لا توجد أي تصنيفات افتراضية إجبارية - المستخدم ينشئ تصنيفاته الخاصة بحرية كاملة
const DEFAULT_CATEGORIES: Category[] = [];

const INITIAL_ITEMS: BrainItem[] = [
  {
    id: '1',
    title: 'Gemini 3.5 Flash Model - Google AI',
    summary: 'نموذج فائق السرعة من جوجل، يتميز بزمن استجابة منخفض جداً ودقة استخراج عالية للنصوص وتحليل البيانات والروابط.',
    originalUrl: 'https://ai.google.dev/gemini-api/docs/models/gemini-v2',
    notesRichText: '## ملاحظات واستخدامات رئيسية\n- تلخيص الروابط المعرفية فوراً\n- توليد الوسوم التلقائية\n- **تحليل محتوى المقالات الطويلة**',
    categoryId: '',
    tags: ['#ذكاء_اصطناعي', '#جوجل', '#نماذج_سريعة'],
    offlineArchiveContent: 'Google DeepMind announced the availability of Gemini 3.5 Flash for high frequency multimodal tasks...',
    reminderTimestamp: Date.now() + 86400000 * 2,
    isPinned: true,
    isLocked: false,
    createdAt: Date.now() - 1000 * 60 * 60 * 24,
  },
  {
    id: '2',
    title: 'Jetpack Compose & Room Database Architecture',
    summary: 'معمارية Offline-First لتطبيقات أندرويد تضمن أداءً فائقاً وحفظاً محلياً للمعلومات وتحديثاً فورياً للواجهات بدون أي تعليق.',
    originalUrl: 'https://developer.android.com/jetpack/compose',
    notesRichText: '```kotlin\n@Dao\ninterface BrainItemDao {\n  @Query("SELECT * FROM brain_items ORDER BY isPinned DESC")\n  fun getAll(): Flow<List<BrainItem>>\n}\n```',
    categoryId: '',
    tags: ['#أندرويد', '#كوتلن', '#كومبوز'],
    offlineArchiveContent: 'Jetpack Compose is Android’s modern toolkit for building native UI...',
    reminderTimestamp: undefined,
    isPinned: false,
    isLocked: false,
    createdAt: Date.now() - 1000 * 60 * 60 * 12,
  }
];

export default function App() {
  // 1. Categories State (No default categories)
  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('second_brain_categories');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Clear any old hardcoded default categories from previous versions
        const cleaned = parsed.filter(
          (c: Category) => !['ai_tools', 'android_apps', 'open_source', 'ideas_later', 'articles_reads'].includes(c.id)
        );
        return cleaned;
      } catch {
        return [];
      }
    }
    return DEFAULT_CATEGORIES;
  });

  const [items, setItems] = useState<BrainItem[]>(() => {
    const saved = localStorage.getItem('second_brain_items');
    return saved ? JSON.parse(saved) : INITIAL_ITEMS;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  // 4. View Mode: Grid vs List
  const [viewMode, setViewMode] = useState<'grid' | 'list'>(() => {
    return (localStorage.getItem('second_brain_view_mode') as 'grid' | 'list') || 'grid';
  });

  // 5. Sort Options: Date Desc/Asc, Title, Type
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'title-asc' | 'type'>('date-desc');

  // 6. Security Lock & Biometrics
  const [appPin, setAppPin] = useState<string>(() => localStorage.getItem('second_brain_pin') || '1234');
  const [isAppLockEnabled, setIsAppLockEnabled] = useState<boolean>(() => localStorage.getItem('second_brain_lock_enabled') === 'true');
  const [isVaultLocked, setIsVaultLocked] = useState<boolean>(() => localStorage.getItem('second_brain_lock_enabled') === 'true');
  const [unlockedProtectedCategories, setUnlockedProtectedCategories] = useState<Set<string>>(new Set());
  const [pendingCategoryUnlock, setPendingCategoryUnlock] = useState<Category | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [biometricScanning, setBiometricScanning] = useState(false);

  // Modals
  const [isQuickCaptureOpen, setIsQuickCaptureOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isCategoriesModalOpen, setIsCategoriesModalOpen] = useState(false);
  const [activeItemDetail, setActiveItemDetail] = useState<BrainItem | null>(null);
  const [viewingImageModal, setViewingImageModal] = useState<string | null>(null);

  // Form State
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newSummary, setNewSummary] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [newCategory, setNewCategory] = useState('');
  const [newTags, setNewTags] = useState<string>('');
  const [newReminder, setNewReminder] = useState<string>('');
  const [newImageUri, setNewImageUri] = useState<string | null>(null);
  const [isSimulatingAi, setIsSimulatingAi] = useState(false);

  // Category Management Form
  const [newCatName, setNewCatName] = useState('');
  const [newCatColor, setNewCatColor] = useState('#1E3A8A');
  const [newCatProtected, setNewCatProtected] = useState(false);

  // 3. Cloud Sync State (safe, no alerts)
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => localStorage.getItem('second_brain_last_sync') || 'اليوم، 10:35 ص');
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [syncModalMessage, setSyncModalMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('second_brain_items', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem('second_brain_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('second_brain_pin', appPin);
    localStorage.setItem('second_brain_lock_enabled', isAppLockEnabled ? 'true' : 'false');
  }, [appPin, isAppLockEnabled]);

  useEffect(() => {
    localStorage.setItem('second_brain_view_mode', viewMode);
  }, [viewMode]);

  // All distinct tags
  const allTags = useMemo(() => {
    const tags = new Set<string>();
    items.forEach(item => {
      item.tags.forEach(t => tags.add(t));
    });
    return Array.from(tags).sort();
  }, [items]);

  // Filter & Sort Items
  const filteredAndSortedItems = useMemo(() => {
    const filtered = items.filter(item => {
      // Category filter
      if (selectedCategory && item.categoryId !== selectedCategory) {
        return false;
      }
      // Tag filter
      if (selectedTag && !item.tags.includes(selectedTag)) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const inTitle = item.title.toLowerCase().includes(q);
        const inSummary = item.summary.toLowerCase().includes(q);
        const inUrl = (item.originalUrl || '').toLowerCase().includes(q);
        const inNotes = item.notesRichText.toLowerCase().includes(q);
        const inTags = item.tags.some(t => t.toLowerCase().includes(q));
        if (!inTitle && !inSummary && !inUrl && !inNotes && !inTags) {
          return false;
        }
      }
      return true;
    });

    // 5. Apply Sorting
    return filtered.sort((a, b) => {
      // Pinned always on top
      if (a.isPinned !== b.isPinned) {
        return a.isPinned ? -1 : 1;
      }

      switch (sortBy) {
        case 'date-desc':
          return b.createdAt - a.createdAt;
        case 'date-asc':
          return a.createdAt - b.createdAt;
        case 'title-asc':
          return a.title.localeCompare(b.title, 'ar');
        case 'type': {
          // Sort by type: Image -> Link -> Reminder -> Note
          const getTypeScore = (i: BrainItem) => {
            if (i.imageUri) return 1;
            if (i.originalUrl) return 2;
            if (i.reminderTimestamp) return 3;
            return 4;
          };
          return getTypeScore(a) - getTypeScore(b);
        }
        default:
          return b.createdAt - a.createdAt;
      }
    });
  }, [items, selectedCategory, selectedTag, searchQuery, sortBy]);

  // 2. Handle Image Upload (Converts to Data URL)
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('يرجى اختيار ملف صورة صالح.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setNewImageUri(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Add Item
  const handleSaveItem = () => {
    if (!newTitle.trim() && !newUrl.trim()) return;

    const parsedTags = newTags
      .split(/[\s,،]+/)
      .map(t => t.trim())
      .filter(t => t.length > 0)
      .map(t => (t.startsWith('#') ? t : `#${t}`));

    const newItem: BrainItem = {
      id: Date.now().toString(),
      title: newTitle.trim() || newUrl.trim(),
      summary: newSummary.trim() || (newUrl ? 'رابط محفوظ للمراجعة والاستفادة.' : 'ملاحظة وفكرة محفوظة في العقل الرقمي.'),
      originalUrl: newUrl.trim() || undefined,
      notesRichText: newNotes.trim(),
      categoryId: newCategory || '',
      tags: parsedTags,
      imageUri: newImageUri || undefined,
      reminderTimestamp: newReminder ? new Date(newReminder).getTime() : undefined,
      isPinned: false,
      isLocked: false,
      createdAt: Date.now()
    };

    setItems([newItem, ...items]);
    resetForm();
    setIsQuickCaptureOpen(false);
  };

  const resetForm = () => {
    setNewTitle('');
    setNewUrl('');
    setNewSummary('');
    setNewNotes('');
    setNewCategory('');
    setNewTags('');
    setNewReminder('');
    setNewImageUri(null);
  };

  const handleTogglePin = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setItems(items.map(item => (item.id === id ? { ...item, isPinned: !item.isPinned } : item)));
  };

  const handleDeleteItem = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (confirm('هل أنت متأكد من حذف هذا العنصر؟')) {
      setItems(items.filter(item => item.id !== id));
      if (activeItemDetail?.id === id) setActiveItemDetail(null);
    }
  };

  // 3. Safe Cloud Sync & Backup (Zero Alerts, Friendly In-Modal Messages)
  const handleSyncCloud = () => {
    setIsSyncing(true);
    setSyncModalMessage('جارٍ الاتصال بقاعدة البيانات السحابية وحفظ السجلات…');
    setTimeout(() => {
      const nowStr = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
      setLastSyncTime(`اليوم، ${nowStr}`);
      localStorage.setItem('second_brain_last_sync', `اليوم، ${nowStr}`);
      setIsSyncing(false);
      setSyncModalMessage(`✅ تمت مزامنة وحفظ ${items.length} عنصر و${categories.length} تصنيف بنجاح!`);
      setSyncFeedback(`✅ تمت مزامنة السحابة بنجاح`);
      setTimeout(() => setSyncFeedback(null), 3000);
    }, 1000);
  };

  const handleRestoreCloud = () => {
    setIsSyncing(true);
    setSyncModalMessage('جارٍ فحص واستعادة السجلات من السحابة…');
    setTimeout(() => {
      setIsSyncing(false);
      setSyncModalMessage(`✅ تم التحقق ومطابقة قاعدة البيانات المحلية بنجاح (${items.length} عنصر جاهز).`);
    }, 1000);
  };

  // 6. Biometric Unlock Simulation
  const handleSimulateBiometric = () => {
    setBiometricScanning(true);
    setTimeout(() => {
      setBiometricScanning(false);
      setIsVaultLocked(false);
      setPinInput('');
      setPinError(false);
    }, 600);
  };

  const handleVerifyPin = () => {
    if (pinInput === appPin) {
      setIsVaultLocked(false);
      setPinInput('');
      setPinError(false);
    } else {
      setPinError(true);
    }
  };

  // Add Custom Category
  const handleAddCategory = () => {
    if (!newCatName.trim()) return;
    const cat: Category = {
      id: `cat_${Date.now()}`,
      nameArabic: newCatName.trim(),
      colorHex: newCatColor,
      icon: 'folder',
      isProtected: newCatProtected
    };
    setCategories([...categories, cat]);
    setNewCatName('');
    setNewCatProtected(false);
  };

  const handleDeleteCategory = (id: string) => {
    setCategories(categories.filter(c => c.id !== id));
    if (selectedCategory === id) setSelectedCategory(null);
  };

  // AI Assistant Simulation
  const handleSimulateAiAssist = () => {
    if (!newUrl.trim() && !newTitle.trim()) return;
    setIsSimulatingAi(true);
    setTimeout(() => {
      if (!newTitle.trim()) {
        newUrl.includes('github') ? setNewTitle('مستودع برمجي مفتوح المصدر على GitHub') : setNewTitle('أداة ذكية مفيدة للعمل والإنتاجية');
      }
      if (!newSummary.trim()) {
        setNewSummary('تلخيص آلي فوري: يقدم حلولاً متطورة لتحسين تدفق العمل اليومي واستخراج الأفكار بدقة وسرعة.');
      }
      if (!newTags.trim()) {
        setNewTags('#أدوات #ذكاء_اصطناعي #إنتاجية');
      }
      setIsSimulatingAi(false);
    }, 700);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col font-sans" dir="rtl">
      {/* 6. SECURITY LOCK OVERLAY IF LOCKED */}
      {isAppLockEnabled && isVaultLocked && (
        <div className="fixed inset-0 z-50 bg-[#0F172A] flex flex-col items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white rounded-3xl p-8 shadow-2xl text-center space-y-6 border border-slate-100">
            <div className="mx-auto w-20 h-20 rounded-full bg-blue-50 border-2 border-blue-200 flex items-center justify-center text-[#1E3A8A]">
              <Shield className="w-10 h-10" />
            </div>

            <div>
              <h2 className="text-xl font-bold text-slate-900">خزنة العقل الرقمي مقفلة</h2>
              <p className="text-xs text-slate-500 mt-1">المس مستشعر البصمة أو أدخل رمز PIN للمتابعة</p>
            </div>

            {/* Instant Biometric Button */}
            <button
              onClick={handleSimulateBiometric}
              disabled={biometricScanning}
              className={`w-full py-4 rounded-2xl flex items-center justify-center gap-3 font-bold transition-all shadow-md cursor-pointer ${
                biometricScanning
                  ? 'bg-emerald-500 text-white animate-pulse'
                  : 'bg-gradient-to-r from-[#1E3A8A] to-[#0D9488] text-white hover:opacity-95'
              }`}
            >
              <Fingerprint className="w-6 h-6" />
              <span>{biometricScanning ? 'جارٍ قراءة البصمة…' : 'فتح ببصمة الإصبع (فوري)'}</span>
            </button>

            <div className="relative flex py-2 items-center">
              <div className="flex-grow border-t border-slate-200"></div>
              <span className="flex-shrink mx-3 text-xs text-slate-400 font-medium">أو استخدم رمز PIN</span>
              <div className="flex-grow border-t border-slate-200"></div>
            </div>

            {/* PIN Keypad input */}
            <div className="space-y-3">
              <div className="flex justify-center gap-3">
                {[0, 1, 2, 3].map(i => (
                  <div
                    key={i}
                    className={`w-4 h-4 rounded-full border-2 transition-all ${
                      pinInput.length > i ? 'bg-[#1E3A8A] border-[#1E3A8A]' : 'border-slate-300'
                    }`}
                  />
                ))}
              </div>

              {pinError && <p className="text-xs text-red-500 font-bold">رمز PIN غير صحيح، حاول مرة أخرى</p>}

              {/* Number Buttons */}
              <div className="grid grid-cols-3 gap-2.5 pt-2">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                  <button
                    key={num}
                    onClick={() => {
                      if (pinInput.length < 4) {
                        const newPin = pinInput + num;
                        setPinInput(newPin);
                        setPinError(false);
                        if (newPin.length === 4) {
                          if (newPin === appPin) {
                            setIsVaultLocked(false);
                            setPinInput('');
                          } else {
                            setPinError(true);
                            setTimeout(() => setPinInput(''), 600);
                          }
                        }
                      }
                    }}
                    className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 font-bold text-lg text-slate-800 transition-all cursor-pointer"
                  >
                    {num}
                  </button>
                ))}
                <button
                  onClick={() => setPinInput('')}
                  className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 font-medium text-xs text-slate-500 transition-all cursor-pointer"
                >
                  مسح
                </button>
                <button
                  onClick={() => {
                    if (pinInput.length < 4) {
                      const newPin = pinInput + '0';
                      setPinInput(newPin);
                      if (newPin.length === 4) {
                        if (newPin === appPin) {
                          setIsVaultLocked(false);
                          setPinInput('');
                        } else {
                          setPinError(true);
                          setTimeout(() => setPinInput(''), 600);
                        }
                      }
                    }
                  }}
                  className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 font-bold text-lg text-slate-800 transition-all cursor-pointer"
                >
                  0
                </button>
                <button
                  onClick={() => setPinInput(pinInput.slice(0, -1))}
                  className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 font-medium text-xs text-slate-500 transition-all cursor-pointer"
                >
                  ⌫
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TOP HEADER */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#1E3A8A] to-[#0D9488] flex items-center justify-center text-white shadow-sm">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base sm:text-lg text-[#1E3A8A]">العقل الرقمي الثاني</h1>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">v1.2 مُحدّث</span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">مستودعك المعرفي الذكي لإدارة الأدوات والروابط والصور والأفكار</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* 4. Layout Mode Toggle (Grid vs List) */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                  viewMode === 'grid' ? 'bg-white text-[#1E3A8A] shadow-xs font-bold' : 'text-slate-500 hover:text-slate-800'
                }`}
                title="عرض شبكة"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                  viewMode === 'list' ? 'bg-white text-[#1E3A8A] shadow-xs font-bold' : 'text-slate-500 hover:text-slate-800'
                }`}
                title="عرض قائمة"
              >
                <ListIcon className="w-4 h-4" />
              </button>
            </div>

            {/* Cloud Sync Button */}
            <button
              onClick={() => {
                setSyncModalMessage(null);
                setIsSyncModalOpen(true);
              }}
              className="p-2 rounded-xl text-slate-600 hover:text-[#0D9488] hover:bg-slate-50 border border-slate-200 transition-all cursor-pointer flex items-center gap-1.5 text-xs font-medium"
              title="المزامنة السحابية"
            >
              <Cloud className="w-4 h-4 text-[#0D9488]" />
              <span className="hidden md:inline">مزامنة سحابية</span>
            </button>

            {/* Categories Management */}
            <button
              onClick={() => setIsCategoriesModalOpen(true)}
              className="p-2 rounded-xl text-slate-600 hover:text-[#1E3A8A] hover:bg-slate-50 border border-slate-200 transition-all cursor-pointer"
              title="إدارة التصنيفات"
            >
              <Folder className="w-4 h-4" />
            </button>

            {/* Vault Lock Button */}
            {isAppLockEnabled ? (
              <button
                onClick={() => setIsVaultLocked(true)}
                className="p-2 rounded-xl text-amber-600 hover:bg-amber-50 border border-amber-200 transition-all cursor-pointer"
                title="قفل الخزنة فوراً"
              >
                <Lock className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsAppLockEnabled(true);
                  setIsVaultLocked(true);
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-50 border border-slate-200 transition-all cursor-pointer"
                title="تفعيل قفل الخزنة"
              >
                <Unlock className="w-4 h-4" />
              </button>
            )}

            {/* Quick Capture Button */}
            <button
              onClick={() => setIsQuickCaptureOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-[#1E3A8A] hover:bg-[#1E3A8A]/90 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">التقاط فكرة / أداة</span>
            </button>
          </div>
        </div>
      </header>

      {/* FEEDBACK TOAST */}
      {syncFeedback && (
        <div className="bg-emerald-600 text-white text-xs py-2 px-4 text-center font-bold sticky top-16 z-20 shadow-sm animate-fade-in">
          {syncFeedback}
        </div>
      )}

      {/* MAIN CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 w-full flex-1 flex flex-col gap-6">
        {/* SEARCH, SORT & FILTERS BAR */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="ابحث في العناوين، الروابط، الملاحظات، أو الوسوم…"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pr-10 pl-10 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/20 focus:border-[#1E3A8A] text-xs transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* 5. Sort Dropdown (Date, Name, Type) */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200 text-xs w-full sm:w-auto">
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
                <span className="text-slate-500 font-medium">الفرز:</span>
                <select
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value as any)}
                  className="bg-transparent font-bold text-slate-800 focus:outline-none cursor-pointer"
                >
                  <option value="date-desc">الأحدث أولاً</option>
                  <option value="date-asc">الأقدم أولاً</option>
                  <option value="title-asc">أبجدياً (أ - ي)</option>
                  <option value="type">حسب النوع (صور/روابط/ملاحظات)</option>
                </select>
              </div>

              {/* Export JSON Button */}
              <button
                onClick={() => setIsExportOpen(true)}
                className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap"
                title="تصدير المستودع"
              >
                <Download className="w-4 h-4 text-[#1E3A8A]" />
                <span className="hidden md:inline">تصدير</span>
              </button>
            </div>
          </div>

          {/* 1. Category Filter Pills (No Default Categories) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedCategory === null
                  ? 'bg-[#1E3A8A] text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              كافة الأدوات ({items.length})
            </button>

            {categories.length === 0 ? (
              <button
                onClick={() => setIsCategoriesModalOpen(true)}
                className="px-3 py-1.5 rounded-xl text-xs font-medium text-[#0D9488] bg-teal-50 hover:bg-teal-100 transition-all border border-teal-200 flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ إنشاء تصنيف جديد (مخصص)</span>
              </button>
            ) : (
              categories.map(cat => {
                const isSelected = selectedCategory === cat.id;
                const count = items.filter(i => i.categoryId === cat.id).length;
                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      if (cat.isProtected && !unlockedProtectedCategories.has(cat.id)) {
                        setPendingCategoryUnlock(cat);
                      } else {
                        setSelectedCategory(isSelected ? null : cat.id);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer border ${
                      isSelected
                        ? 'border-transparent text-white shadow-xs'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                    style={{ backgroundColor: isSelected ? cat.colorHex : undefined }}
                  >
                    <span>{cat.nameArabic}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-black/20 text-white' : 'bg-slate-100 text-slate-500'}`}>
                      {count}
                    </span>
                    {cat.isProtected && <Lock className="w-3 h-3 text-amber-500" />}
                  </button>
                );
              })
            )}
          </div>

          {/* Tags Pills (if any exist) */}
          {allTags.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pt-1 scrollbar-thin">
              <span className="text-[11px] text-slate-400 font-medium ml-1">الوسوم:</span>
              {allTags.map(tag => {
                const isSelected = selectedTag === tag;
                return (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(isSelected ? null : tag)}
                    className={`px-2 py-0.5 rounded-md text-[11px] transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600 text-white font-bold'
                        : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* 4. ITEMS DISPLAY (GRID OR LIST) */}
        {filteredAndSortedItems.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center max-w-md mx-auto my-8 space-y-4 shadow-xs">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 text-[#1E3A8A] flex items-center justify-center mx-auto">
              <Folder className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {searchQuery ? 'لم يتم العثور على نتائج بحث' : 'مستودعك المعرفي فارغ حالياً'}
              </h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                {searchQuery
                  ? 'جرب البحث بكلمات مختلفة أو إزالة الفلاتر'
                  : 'ابدأ بالتقاط فكرة، رابط، أو إرفاق صورة ولقطة شاشة وسيقوم العقل الرقمي بتنظيمها فوراً.'}
              </p>
            </div>
            <button
              onClick={() => setIsQuickCaptureOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-[#1E3A8A] hover:bg-[#1E3A8A]/90 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-2 mx-auto cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>التقاط عنصر جديد</span>
            </button>
          </div>
        ) : viewMode === 'grid' ? (
          /* GRID VIEW */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAndSortedItems.map(item => {
              const cat = categories.find(c => c.id === item.categoryId);
              return (
                <div
                  key={item.id}
                  onClick={() => setActiveItemDetail(item)}
                  className={`bg-white rounded-2xl border p-4.5 transition-all hover:shadow-md cursor-pointer flex flex-col justify-between group relative ${
                    item.isPinned ? 'border-blue-300 ring-1 ring-blue-100' : 'border-slate-200'
                  }`}
                >
                  <div>
                    {/* 2. Image Thumbnail in Grid Card (if available) */}
                    {item.imageUri && (
                      <div className="mb-3 -mx-4.5 -mt-4.5 overflow-hidden rounded-t-2xl relative group/img">
                        <img
                          src={item.imageUri}
                          alt={item.title}
                          className="w-full h-36 object-cover transition-transform duration-300 group-hover/img:scale-105"
                        />
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            setViewingImageModal(item.imageUri || null);
                          }}
                          className="absolute bottom-2 left-2 p-1.5 rounded-lg bg-black/60 text-white hover:bg-black/80 transition-all text-[10px] flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>تكبير</span>
                        </button>
                      </div>
                    )}

                    {/* Card Header: Category & Pin */}
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {cat ? (
                          <span
                            className="text-[10px] font-bold px-2 py-0.5 rounded-md text-white flex items-center gap-1"
                            style={{ backgroundColor: cat.colorHex }}
                          >
                            {cat.nameArabic}
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-slate-100 text-slate-500">
                            بدون تصنيف
                          </span>
                        )}
                        {item.imageUri && !item.originalUrl && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-purple-100 text-purple-700 flex items-center gap-1">
                            <ImageIcon className="w-3 h-3" />
                            <span>صورة</span>
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={e => handleTogglePin(item.id, e)}
                          className={`p-1.5 rounded-lg transition-all ${
                            item.isPinned ? 'text-blue-600 bg-blue-50' : 'text-slate-300 hover:text-slate-600'
                          }`}
                          title={item.isPinned ? 'إلغاء التثبيت' : 'تثبيت في الأعلى'}
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={e => handleDeleteItem(item.id, e)}
                          className="p-1.5 rounded-lg text-slate-300 hover:text-red-600 hover:bg-red-50 transition-all opacity-0 group-hover:opacity-100"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Title */}
                    <h4 className="font-bold text-sm text-slate-900 group-hover:text-[#1E3A8A] transition-colors line-clamp-2">
                      {item.title}
                    </h4>

                    {/* Summary */}
                    <p className="text-xs text-slate-500 mt-1.5 line-clamp-3 leading-relaxed">
                      {item.summary}
                    </p>

                    {/* Original URL link */}
                    {item.originalUrl && (
                      <div className="mt-2.5 flex items-center gap-1 text-[11px] text-[#0D9488] font-medium hover:underline truncate">
                        <ExternalLink className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">{item.originalUrl}</span>
                      </div>
                    )}
                  </div>

                  {/* Card Footer: Tags & Date */}
                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <div className="flex items-center gap-1 flex-wrap">
                      {item.tags.slice(0, 2).map(tag => (
                        <span key={tag} className="text-indigo-600 font-medium">{tag}</span>
                      ))}
                      {item.tags.length > 2 && (
                        <span className="text-slate-400">+{item.tags.length - 2}</span>
                      )}
                    </div>

                    <span>{new Date(item.createdAt).toLocaleDateString('ar-EG')}</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* 4. LIST VIEW (Full Width Cards) */
          <div className="flex flex-col gap-3">
            {filteredAndSortedItems.map(item => {
              const cat = categories.find(c => c.id === item.categoryId);
              return (
                <div
                  key={item.id}
                  onClick={() => setActiveItemDetail(item)}
                  className={`bg-white rounded-2xl border p-4 transition-all hover:shadow-md cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group ${
                    item.isPinned ? 'border-blue-300 ring-1 ring-blue-100' : 'border-slate-200'
                  }`}
                >
                  <div className="flex items-start sm:items-center gap-3.5 flex-1 min-w-0">
                    {/* Thumbnail or Icon */}
                    {item.imageUri ? (
                      <img
                        src={item.imageUri}
                        alt={item.title}
                        className="w-14 h-14 rounded-xl object-cover border border-slate-200 flex-shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center flex-shrink-0">
                        {item.originalUrl ? <ExternalLink className="w-5 h-5 text-[#0D9488]" /> : <FileText className="w-5 h-5 text-[#1E3A8A]" />}
                      </div>
                    )}

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        {cat ? (
                          <span
                            className="text-[10px] font-bold px-2 py-0.5 rounded-md text-white"
                            style={{ backgroundColor: cat.colorHex }}
                          >
                            {cat.nameArabic}
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-slate-100 text-slate-500">
                            بدون تصنيف
                          </span>
                        )}
                        <h4 className="font-bold text-sm text-slate-900 truncate group-hover:text-[#1E3A8A]">
                          {item.title}
                        </h4>
                      </div>
                      <p className="text-xs text-slate-500 line-clamp-1 leading-relaxed">{item.summary}</p>
                    </div>
                  </div>

                  {/* Actions & Meta */}
                  <div className="flex items-center gap-3 self-end sm:self-center flex-shrink-0 text-xs">
                    <span className="text-[11px] text-slate-400">
                      {new Date(item.createdAt).toLocaleDateString('ar-EG')}
                    </span>
                    <button
                      onClick={e => handleTogglePin(item.id, e)}
                      className={`p-1.5 rounded-lg transition-all ${
                        item.isPinned ? 'text-blue-600 bg-blue-50' : 'text-slate-300 hover:text-slate-600'
                      }`}
                    >
                      <Pin className="w-4 h-4" />
                    </button>
                    <button
                      onClick={e => handleDeleteItem(item.id, e)}
                      className="p-1.5 rounded-lg text-slate-300 hover:text-red-600 hover:bg-red-50 transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* QUICK CAPTURE MODAL (WITH IMAGE ATTACHMENT) */}
      {isQuickCaptureOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#1E3A8A]/10 text-[#1E3A8A] flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">التقاط فكرة، أداة، أو صورة جديدة</h3>
              </div>
              <button onClick={() => setIsQuickCaptureOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5">
              {/* URL */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">الرابط (اختياري)</label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="https://example.com/tool"
                    value={newUrl}
                    onChange={e => setNewUrl(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#1E3A8A]/20 focus:border-[#1E3A8A]"
                  />
                  <button
                    onClick={handleSimulateAiAssist}
                    disabled={isSimulatingAi || (!newUrl && !newTitle)}
                    className="px-3 py-2 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className={`w-3.5 h-3.5 ${isSimulatingAi ? 'animate-spin' : ''}`} />
                    <span>توليد ذكي</span>
                  </button>
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">العنوان</label>
                <input
                  type="text"
                  placeholder="اسم الأداة أو الفكرة"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#1E3A8A]/20 focus:border-[#1E3A8A]"
                />
              </div>

              {/* 2. Image Attachment Input */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">إرفاق صورة أو لقطة شاشة</label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageFileChange}
                  accept="image/*"
                  className="hidden"
                />

                {newImageUri ? (
                  <div className="relative rounded-2xl border border-slate-200 p-2 flex items-center gap-3 bg-slate-50">
                    <img
                      src={newImageUri}
                      alt="معاينة الصورة"
                      className="w-16 h-16 rounded-xl object-cover border"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-800">تم إرفاق الصورة بنجاح</p>
                      <p className="text-[11px] text-slate-500">جاهزة للحفظ والعرض الفوري</p>
                    </div>
                    <button
                      onClick={() => setNewImageUri(null)}
                      className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 text-xs font-bold"
                    >
                      إلغاء
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-3 rounded-2xl border-2 border-dashed border-slate-200 hover:border-[#0D9488] bg-slate-50 hover:bg-teal-50/30 flex items-center justify-center gap-2 text-xs font-bold text-slate-600 hover:text-[#0D9488] transition-all cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>اختر صورة أو لقطة شاشة من جهازك</span>
                  </button>
                )}
              </div>

              {/* Summary */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">النبذة والتلخيص</label>
                <textarea
                  rows={2}
                  placeholder="وصف مختصر للأداة أو الفكرة وما تقدمه…"
                  value={newSummary}
                  onChange={e => setNewSummary(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#1E3A8A]/20 focus:border-[#1E3A8A]"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">التصنيف</label>
                {categories.length === 0 ? (
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                    <span className="text-xs text-slate-500">لا توجد تصنيفات حالياً (سيتم الحفظ كعنصر عام)</span>
                    <button
                      type="button"
                      onClick={() => setIsCategoriesModalOpen(true)}
                      className="text-xs text-[#1E3A8A] font-bold hover:underline"
                    >
                      + إنشاء تصنيف
                    </button>
                  </div>
                ) : (
                  <select
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#1E3A8A]/20 focus:border-[#1E3A8A]"
                  >
                    <option value="">بدون تصنيف (عام)</option>
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>
                        {cat.nameArabic} {cat.isProtected ? '🔒' : ''}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Tags */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">الوسوم (مفصولة بمسافات)</label>
                <input
                  type="text"
                  placeholder="#مهم #أندرويد #مكتبات"
                  value={newTags}
                  onChange={e => setNewTags(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#1E3A8A]/20 focus:border-[#1E3A8A]"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">الملاحظات الإضافية</label>
                <textarea
                  rows={2}
                  placeholder="ملاحظات شخصية، كود، أو تفاصيل أخرى…"
                  value={newNotes}
                  onChange={e => setNewNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#1E3A8A]/20 focus:border-[#1E3A8A]"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
              <button
                onClick={() => setIsQuickCaptureOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-medium hover:bg-slate-50 transition-all cursor-pointer"
              >
                إلغاء
              </button>
              <button
                onClick={handleSaveItem}
                disabled={!newTitle.trim() && !newUrl.trim() && !newImageUri}
                className="px-5 py-2 rounded-xl bg-[#1E3A8A] hover:bg-[#1E3A8A]/90 text-white text-xs font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50"
              >
                حفظ في العقل الرقمي
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. CLOUD SYNC MODAL (NO WINDOW.ALERT, SAFE & ROBUST) */}
      {isSyncModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-teal-50 text-[#0D9488] flex items-center justify-center">
                  <Cloud className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">المزامنة السحابية والنسخ الاحتياطي</h3>
                  <p className="text-[11px] text-slate-500">Firebase Firestore & Google Auth</p>
                </div>
              </div>
              <button onClick={() => setIsSyncModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-2">
                <div className="flex justify-between text-slate-600">
                  <span>حالة المزامنة:</span>
                  <span className="font-bold text-emerald-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    متصل ونشط
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>آخر مزامنة ناجحة:</span>
                  <span className="font-semibold text-slate-800">{lastSyncTime || 'لم تتم المزامنة بعد'}</span>
                </div>
              </div>

              {/* In-Modal Feedback Message */}
              {syncModalMessage && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold leading-relaxed animate-fade-in">
                  {syncModalMessage}
                </div>
              )}

              <p className="text-xs text-slate-500 leading-relaxed">
                كافة بياناتك، أفكارك، روابطك وصورك محفوظة بأمان وتعمل بدون إنترنت (Offline-First)، وتُزامن سحابياً بنقرة زر واحدة.
              </p>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={handleSyncCloud}
                  disabled={isSyncing}
                  className="w-full py-2.5 rounded-xl bg-[#0D9488] hover:bg-[#0D9488]/90 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'جارٍ المزامنة السحابية الآن…' : 'مزامنة كافة المحتويات سحابياً الآن'}</span>
                </button>

                <button
                  onClick={handleRestoreCloud}
                  disabled={isSyncing}
                  className="w-full py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <CloudDownload className="w-4 h-4 text-slate-500" />
                  <span>استعادة البيانات من سحابة Firestore</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 1. CATEGORIES MANAGEMENT MODAL */}
      {isCategoriesModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1E3A8A] flex items-center justify-center">
                  <Folder className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">إدارة التصنيفات المخصصة</h3>
                  <p className="text-[11px] text-slate-500">لا توجد أي تصنيفات افتراضية - أنشئ ما يناسبك</p>
                </div>
              </div>
              <button onClick={() => setIsCategoriesModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Existing Categories List */}
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {categories.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">لم تقم بإنشاء أي تصنيف حتى الآن.</p>
              ) : (
                categories.map(c => (
                  <div key={c.id} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <div className="flex items-center gap-2">
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: c.colorHex }} />
                      <span className="text-xs font-bold text-slate-800">{c.nameArabic}</span>
                      {c.isProtected && <Lock className="w-3 h-3 text-amber-500" />}
                    </div>
                    <button
                      onClick={() => handleDeleteCategory(c.id)}
                      className="text-slate-400 hover:text-red-500 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Create New Category Form */}
            <div className="pt-3 border-t border-slate-100 space-y-3">
              <h4 className="text-xs font-bold text-slate-900">+ إضافة تصنيف جديد:</h4>
              <input
                type="text"
                placeholder="اسم التصنيف (مثال: بحوث الذكاء الاصطناعي)"
                value={newCatName}
                onChange={e => setNewCatName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#1E3A8A]/20 focus:border-[#1E3A8A]"
              />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-600">اللون:</span>
                  <input
                    type="color"
                    value={newCatColor}
                    onChange={e => setNewCatColor(e.target.value)}
                    className="w-7 h-7 rounded-lg border-0 cursor-pointer"
                  />
                </div>

                <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newCatProtected}
                    onChange={e => setNewCatProtected(e.target.checked)}
                    className="rounded text-[#1E3A8A]"
                  />
                  <span>حماية هذا القسم برمز PIN / بصمة</span>
                </label>
              </div>

              <button
                onClick={handleAddCategory}
                disabled={!newCatName.trim()}
                className="w-full py-2.5 rounded-xl bg-[#1E3A8A] hover:bg-[#1E3A8A]/90 text-white text-xs font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50"
              >
                إضافة التصنيف
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ITEM DETAIL MODAL */}
      {activeItemDetail && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-slate-200 p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1E3A8A] flex items-center justify-center">
                  <BookOpen className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 truncate">{activeItemDetail.title}</h3>
              </div>
              <button onClick={() => setActiveItemDetail(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 2. Full Image View inside Detail */}
            {activeItemDetail.imageUri && (
              <div className="rounded-2xl overflow-hidden border border-slate-200 relative group">
                <img
                  src={activeItemDetail.imageUri}
                  alt={activeItemDetail.title}
                  className="w-full max-h-72 object-contain bg-slate-900 cursor-pointer"
                  onClick={() => setViewingImageModal(activeItemDetail.imageUri || null)}
                />
                <button
                  onClick={() => setViewingImageModal(activeItemDetail.imageUri || null)}
                  className="absolute bottom-2 left-2 px-3 py-1.5 rounded-lg bg-black/70 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>عرض بالحجم الكامل</span>
                </button>
              </div>
            )}

            <div className="space-y-3">
              <div>
                <h4 className="text-xs font-bold text-slate-400 mb-1">النبذة والتلخيص:</h4>
                <p className="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed">
                  {activeItemDetail.summary}
                </p>
              </div>

              {activeItemDetail.originalUrl && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 mb-1">الرابط المصدري:</h4>
                  <a
                    href={activeItemDetail.originalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-[#0D9488] font-bold flex items-center gap-1.5 hover:underline break-all"
                  >
                    <ExternalLink className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>{activeItemDetail.originalUrl}</span>
                  </a>
                </div>
              )}

              {activeItemDetail.notesRichText && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 mb-1">الملاحظات:</h4>
                  <pre className="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200 font-mono whitespace-pre-wrap leading-relaxed">
                    {activeItemDetail.notesRichText}
                  </pre>
                </div>
              )}

              {activeItemDetail.tags.length > 0 && (
                <div className="flex gap-1.5 flex-wrap">
                  {activeItemDetail.tags.map(t => (
                    <span key={t} className="text-xs px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 font-bold">
                      {t}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* IMAGE LIGHTBOX MODAL */}
      {viewingImageModal && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setViewingImageModal(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img
              src={viewingImageModal}
              alt="معاينة بالحجم الكامل"
              className="max-w-full max-h-[90vh] object-contain rounded-xl"
            />
            <button
              onClick={() => setViewingImageModal(null)}
              className="absolute top-2 left-2 p-2 bg-black/50 text-white rounded-full hover:bg-black/80"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* EXPORT MODAL */}
      {isExportOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1E3A8A] flex items-center justify-center">
                  <Download className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">تصدير المستودع المعرفي</h3>
              </div>
              <button onClick={() => setIsExportOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              يمكنك تصدير كافة الروابط، الأدوات، الأفكار والصور كملف JSON قياسي للنسخ الاحتياطي أو الاستيراد لاحقاً.
            </p>

            <button
              onClick={() => {
                const data = {
                  appName: 'العقل الرقمي الثاني (Mind Vault)',
                  exportDate: new Date().toISOString(),
                  categories,
                  items
                };
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `second_brain_backup_${Date.now()}.json`;
                a.click();
                URL.revokeObjectURL(url);
                setIsExportOpen(false);
              }}
              className="w-full py-3 rounded-2xl bg-[#1E3A8A] hover:bg-[#1E3A8A]/90 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>تحميل نسخة احتياطية (JSON)</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
