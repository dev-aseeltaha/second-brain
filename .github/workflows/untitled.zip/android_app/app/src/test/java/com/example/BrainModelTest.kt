package com.example

import com.example.data.export.ExportManager
import com.example.data.model.BrainItem
import com.example.data.model.BrainTypeConverters
import com.example.data.model.Category
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class BrainModelTest {

    @Test
    fun defaultCategories_containsExpectedCategories() {
        val categories = Category.getDefaultCategories()
        assertTrue(categories.isNotEmpty())
        assertTrue(categories.any { it.id == "ai_tools" })
        assertTrue(categories.any { it.id == "android_apps" })
        assertTrue(categories.any { it.id == "open_source" })
    }

    @Test
    fun brainTypeConverters_serializesAndDeserializesTags() {
        val converters = BrainTypeConverters()
        val tags = listOf("#ذكاء_اصطناعي", "#مفتوح_المصدر", "#أدوات")
        val json = converters.fromStringList(tags)
        assertNotNull(json)
        val deserialized = converters.toStringList(json)
        assertEquals(tags, deserialized)
    }

    @Test
    fun exportManager_exportsValidJsonAndMarkdown() {
        val categories = Category.getDefaultCategories()
        val items = listOf(
            BrainItem(
                id = "test_1",
                title = "أداة تجريبية",
                summary = "هذه نبذة تجريبية لاختبار التصدير",
                originalUrl = "https://example.com",
                categoryId = "ai_tools",
                tags = listOf("#تجربة")
            )
        )

        val jsonExport = ExportManager.exportToJson(items, categories)
        assertTrue(jsonExport.contains("العقل الرقمي"))
        assertTrue(jsonExport.contains("أداة تجريبية"))

        val mdExport = ExportManager.exportToMarkdown(items, categories)
        assertTrue(mdExport.contains("# أرشيف العقل الرقمي"))
        assertTrue(mdExport.contains("أداة تجريبية"))
    }

    @Test
    fun category_protectedFlags_areCorrect() {
        val categories = Category.getDefaultCategories()
        val ideasCategory = categories.find { it.id == "ideas_later" }
        assertNotNull(ideasCategory)
        assertTrue(ideasCategory?.isProtected == true)
    }

    @Test
    fun securityManager_hashesPinCorrectly() {
        val pin = "1234"
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val hash = md.digest(pin.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        assertEquals(64, hash.length)
    }
}
