package com.example.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.R
import com.example.data.local.BrainDatabase
import com.example.network.GeminiAiService
import com.example.network.WebScraper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

class LinkEnrichmentWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    companion object {
        const val KEY_ITEM_ID = "item_id"
        const val KEY_URL = "url"
        const val CHANNEL_ID = "brain_enrichment_channel"
        const val NOTIFICATION_ID = 2001
    }

    override suspend fun doWork(): Result {
        val itemId = inputData.getString(KEY_ITEM_ID) ?: return Result.failure()
        val url = inputData.getString(KEY_URL) ?: return Result.failure()

        val db = BrainDatabase.getDatabase(context, CoroutineScope(Dispatchers.IO))
        val dao = db.brainItemDao()
        val item = dao.getItemByIdDirect(itemId) ?: return Result.failure()

        try {
            // 1. Scrape web data using Jsoup
            val scrapedData = WebScraper.scrapeUrl(url)

            // 2. Generate Smart AI summary and categorization using Gemini
            val aiResult = GeminiAiService.generateSummary(
                title = if (item.title.isNotBlank() && !item.title.startsWith("http")) item.title else scrapedData.title,
                url = url,
                rawContent = scrapedData.fullTextExcerpt.ifBlank { scrapedData.description }
            )

            // 3. Update item with enriched metadata and offline archive text
            val updatedTitle = if (item.title.isBlank() || item.title.startsWith("http")) {
                scrapedData.title.ifBlank { item.title }
            } else {
                item.title
            }

            val mergedTags = (item.tags + aiResult.suggestedTags + scrapedData.suggestedTags).distinct()
            val targetCategory = if (item.categoryId == "uncategorized" || item.categoryId.isBlank()) {
                aiResult.suggestedCategory ?: scrapedData.suggestedCategory ?: "ai_tools"
            } else {
                item.categoryId
            }

            val updatedItem = item.copy(
                title = updatedTitle,
                summary = aiResult.summary.ifBlank { scrapedData.description },
                tags = mergedTags,
                categoryId = targetCategory,
                offlineArchiveContent = scrapedData.fullTextExcerpt,
                enrichmentStatus = "READY",
                updatedAt = System.currentTimeMillis()
            )

            dao.updateItem(updatedItem)

            // 4. Post local notification informing the user of successful enrichment
            showSuccessNotification(context, updatedTitle)

            return Result.success()
        } catch (e: Exception) {
            dao.updateItem(item.copy(enrichmentStatus = "FAILED"))
            return Result.retry()
        }
    }

    private fun showSuccessNotification(context: Context, title: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "إشعارات العقل الرقمي الذكية",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعارات تلخيص الروابط وتنظيم الأدوات في الخلفية"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("العقل الرقمي: تم التلخيص والتنظيم بنجاح")
            .setContentText("تم حفظ ونبذة: $title")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }
}
