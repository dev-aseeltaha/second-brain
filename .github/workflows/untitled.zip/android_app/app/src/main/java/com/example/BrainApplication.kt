package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.data.repository.BrainRepository
import com.example.security.SecurityManager
import com.example.service.ReminderBroadcastReceiver
import com.example.worker.LinkEnrichmentWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class BrainApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var repository: BrainRepository
        private set
    lateinit var securityManager: SecurityManager
        private set
    lateinit var syncManager: com.example.data.sync.FirestoreSyncManager
        private set

    override fun onCreate() {
        super.onCreate()
        repository = BrainRepository(this, applicationScope)
        securityManager = SecurityManager(this)
        syncManager = com.example.data.sync.FirestoreSyncManager(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            val enrichmentChannel = NotificationChannel(
                LinkEnrichmentWorker.CHANNEL_ID,
                "إشعارات التلخيص الذكي",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعارات تلخيص الروابط وتنظيم الأدوات في الخلفية"
            }

            val reminderChannel = NotificationChannel(
                ReminderBroadcastReceiver.CHANNEL_ID,
                "تذكيرات جرّبه لاحقاً",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات لمراجعة وتجربة الأدوات والأفكار المحفوظة"
                enableVibration(true)
            }

            notificationManager?.createNotificationChannel(enrichmentChannel)
            notificationManager?.createNotificationChannel(reminderChannel)
        }
    }
}
