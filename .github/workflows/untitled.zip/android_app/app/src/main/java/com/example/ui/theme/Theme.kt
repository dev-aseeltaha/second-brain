package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val AppLightColorScheme = lightColorScheme(
    primary = BrainPrimary,
    onPrimary = BrainOnPrimary,
    primaryContainer = BrainPrimaryContainer,
    onPrimaryContainer = BrainOnPrimaryContainer,
    secondary = BrainSecondary,
    onSecondary = BrainOnSecondary,
    secondaryContainer = BrainSecondaryContainer,
    onSecondaryContainer = BrainOnSecondaryContainer,
    tertiary = BrainTertiary,
    onTertiary = BrainOnTertiary,
    tertiaryContainer = BrainTertiaryContainer,
    background = BrainBackground,
    onBackground = BrainOnBackground,
    surface = BrainSurface,
    onSurface = BrainOnSurface,
    surfaceVariant = BrainSurfaceVariant,
    onSurfaceVariant = BrainOnSurfaceVariant,
    outline = BrainOutline,
    outlineVariant = BrainOutlineVariant,
    error = BrainError,
    onError = BrainOnError,
    errorContainer = BrainErrorContainer,
    onErrorContainer = BrainOnErrorContainer
)

/**
 * Pure Light Theme for MindVault (Second Brain).
 * Per strict user requirements: Always Light Mode (No Dark Mode), clean, comfortable, and eye-friendly.
 * Enforces RTL LayoutDirection by default for Arabic UI.
 */
@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = AppLightColorScheme,
            typography = Typography,
            content = content
        )
    }
}
