package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure Light Theme Color Palette - Clean, Modern, & Eye-friendly
val BrainPrimary = Color(0xFF1E3A8A) // Deep Royal Indigo/Navy
val BrainOnPrimary = Color(0xFFFFFFFF)
val BrainPrimaryContainer = Color(0xFFEEF2FF)
val BrainOnPrimaryContainer = Color(0xFF1E293B)

val BrainSecondary = Color(0xFF0D9488) // Refined Teal/Emerald
val BrainOnSecondary = Color(0xFFFFFFFF)
val BrainSecondaryContainer = Color(0xFFCCFBF1)
val BrainOnSecondaryContainer = Color(0xFF115E59)

val BrainTertiary = Color(0xFF6366F1) // Soft Iris
val BrainOnTertiary = Color(0xFFFFFFFF)
val BrainTertiaryContainer = Color(0xFFE0E7FF)

val BrainBackground = Color(0xFFF8FAFC) // Soothing light slate/chalk
val BrainOnBackground = Color(0xFF0F172A)

val BrainSurface = Color(0xFFFFFFFF) // Crisp white card surface
val BrainOnSurface = Color(0xFF0F172A)
val BrainSurfaceVariant = Color(0xFFF1F5F9) // Slightly shaded containers / chips
val BrainOnSurfaceVariant = Color(0xFF334155)

val BrainOutline = Color(0xFFE2E8F0) // Subtle card border
val BrainOutlineVariant = Color(0xFFCBD5E1)

val BrainSuccess = Color(0xFF10B981)
val BrainWarning = Color(0xFFF59E0B)
val BrainError = Color(0xFFEF4444)
val BrainOnError = Color(0xFFFFFFFF)
val BrainErrorContainer = Color(0xFFFEE2E2)
val BrainOnErrorContainer = Color(0xFF991B1B)
