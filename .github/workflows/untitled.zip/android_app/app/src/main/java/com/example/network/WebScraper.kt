package com.example.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

data class ScrapedWebData(
    val title: String,
    val description: String,
    val fullTextExcerpt: String,
    val imageUrl: String?,
    val suggestedCategory: String?,
    val suggestedTags: List<String>
)

object WebScraper {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun scrapeUrl(url: String): ScrapedWebData = withContext(Dispatchers.IO) {
        val safeUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) {
            "https://$url"
        } else {
            url
        }

        try {
            val request = Request.Builder()
                .url(safeUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 MindVault/1.0")
                .build()

            val response = client.newCall(request).execute()
            val html = response.body?.string() ?: ""
            val doc = Jsoup.parse(html, safeUrl)

            // Extract titles with fallback
            val ogTitle = doc.select("meta[property=og:title]").attr("content")
            val twitterTitle = doc.select("meta[name=twitter:title]").attr("content")
            val docTitle = doc.title()
            val finalTitle = when {
                ogTitle.isNotBlank() -> ogTitle
                docTitle.isNotBlank() -> docTitle
                twitterTitle.isNotBlank() -> twitterTitle
                else -> safeUrl.substringAfter("://").substringBefore("/")
            }.trim()

            // Extract descriptions
            val ogDesc = doc.select("meta[property=og:description]").attr("content")
            val metaDesc = doc.select("meta[name=description]").attr("content")
            val twitterDesc = doc.select("meta[name=twitter:description]").attr("content")
            val finalDesc = when {
                ogDesc.isNotBlank() -> ogDesc
                metaDesc.isNotBlank() -> metaDesc
                twitterDesc.isNotBlank() -> twitterDesc
                else -> ""
            }.trim()

            // Extract main image
            val ogImage = doc.select("meta[property=og:image]").attr("content")
            val finalImage = if (ogImage.isNotBlank()) ogImage else null

            // Extract clean body text excerpt
            val paragraphs = doc.select("article p, main p, body p").eachText().joinToString(" ")
            val cleanExcerpt = if (paragraphs.isNotBlank()) {
                paragraphs.take(2500)
            } else {
                doc.body().text().take(1500)
            }

            // Auto-category suggestion based on domain / keywords
            val domain = safeUrl.lowercase()
            val suggestedCat = when {
                domain.contains("github.com") || domain.contains("gitlab.com") || domain.contains("sourceforge.net") -> "open_source"
                domain.contains("play.google.com") || domain.contains("apkpure.com") || domain.contains("f-droid.org") -> "android_apps"
                domain.contains("huggingface.co") || domain.contains("openai.com") || domain.contains("ai.google") ||
                        domain.contains("anthropic.com") || domain.contains("midjourney.com") || domain.contains("deepseek") -> "ai_tools"
                domain.contains("microsoft.com") || domain.contains("chocolatey.org") -> "windows_software"
                else -> null
            }

            // Suggested initial tags
            val tags = mutableListOf<String>()
            if (domain.contains("github.com")) tags.add("#مفتوح_المصدر")
            if (domain.contains("play.google.com")) tags.add("#تطبيق_أندرويد")
            if (domain.contains("ai") || cleanExcerpt.contains("AI", ignoreCase = true) || cleanExcerpt.contains("ذكاء", ignoreCase = true)) tags.add("#ذكاء_اصطناعي")

            ScrapedWebData(
                title = finalTitle,
                description = finalDesc,
                fullTextExcerpt = cleanExcerpt,
                imageUrl = finalImage,
                suggestedCategory = suggestedCat,
                suggestedTags = tags
            )
        } catch (e: Exception) {
            // Fallback for offline or unreachable site
            val fallbackTitle = safeUrl.substringAfter("://").substringBefore("/").replaceFirstChar { it.uppercase() }
            ScrapedWebData(
                title = fallbackTitle,
                description = "تم حفظ الرابط: $safeUrl",
                fullTextExcerpt = "",
                imageUrl = null,
                suggestedCategory = null,
                suggestedTags = listOf("#رابط")
            )
        }
    }
}
