package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Category / Drawer in the Second Brain.
 * e.g., أدوات AI, تطبيقات أندرويد, مشاريع مفتوحة, برامج ويندوز, وكلاء ذكاء اصطناعي, أفكار للتنفيذ لاحقاً
 */
@Entity(tableName = "categories")
data class Category(
    @PrimaryKey
    val id: String,
    val nameArabic: String,
    val iconKey: String = "folder",
    val colorHex: String = "#1E3A8A",
    val isSystemDefault: Boolean = false,
    val isProtected: Boolean = false, // Protected by App Lock PIN / Biometric
    val sortOrder: Int = 0
) {
    companion object {
        fun getDefaultCategories(): List<Category> = emptyList()
    }
}
