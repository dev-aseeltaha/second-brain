package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

object CategoryIconHelper {

    fun getIcon(iconKey: String): ImageVector {
        return when (iconKey.lowercase()) {
            "psychology", "brain", "ai" -> Icons.Default.Psychology
            "android", "mobile" -> Icons.Default.Android
            "code", "github" -> Icons.Default.Code
            "computer", "windows", "desktop" -> Icons.Default.Computer
            "smart_toy", "robot", "agent" -> Icons.Default.SmartToy
            "lightbulb", "idea" -> Icons.Default.Lightbulb
            "star", "favorite" -> Icons.Default.Star
            "bookmark" -> Icons.Default.Bookmark
            "terminal" -> Icons.Default.Terminal
            "widgets" -> Icons.Default.Widgets
            else -> Icons.Default.Folder
        }
    }

    fun parseColor(hex: String, defaultColor: Color = Color(0xFF1E3A8A)): Color {
        return try {
            val cleanHex = hex.removePrefix("#")
            val colorLong = cleanHex.toLong(16)
            if (cleanHex.length == 6) {
                Color(colorLong or 0x00000000FF000000)
            } else {
                Color(colorLong)
            }
        } catch (e: Exception) {
            defaultColor
        }
    }
}
