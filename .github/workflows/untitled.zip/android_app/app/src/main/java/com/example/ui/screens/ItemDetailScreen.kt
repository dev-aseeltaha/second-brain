package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrainItem
import com.example.data.model.Category
import com.example.ui.components.CategoryIconHelper
import com.example.ui.theme.BrainBackground
import com.example.ui.theme.BrainOutline
import com.example.ui.theme.BrainPrimary
import com.example.ui.theme.BrainSecondary
import com.example.ui.theme.BrainSurface
import com.example.ui.theme.BrainSurfaceVariant
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ItemDetailScreen(
    item: BrainItem,
    category: Category?,
    onBack: () -> Unit,
    onSaveUpdate: (BrainItem) -> Unit,
    onTogglePin: (BrainItem) -> Unit,
    onDelete: (String) -> Unit,
    onReEnrich: (BrainItem) -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    var title by remember(item.id) { mutableStateOf(item.title) }
    var summary by remember(item.id) { mutableStateOf(item.summary) }
    var notes by remember(item.id) { mutableStateOf(item.notesRichText) }
    val tags = remember(item.id) { mutableStateListOf<String>().apply { addAll(item.tags) } }
    var newTagInput by remember { mutableStateOf("") }
    var reminderTime by remember(item.id) { mutableStateOf(item.reminderTimestamp) }
    var isArchiveExpanded by remember { mutableStateOf(false) }
    var isReEnriching by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تفاصيل الأداة والملاحظات",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrainPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = BrainPrimary
                        )
                    }
                },
                actions = {
                    // Pin toggle
                    IconButton(onClick = { onTogglePin(item) }) {
                        Icon(
                            imageVector = if (item.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "تثبيت",
                            tint = if (item.isPinned) BrainPrimary else Color(0xFF64748B)
                        )
                    }
                    // Share
                    IconButton(onClick = {
                        val shareText = buildString {
                            append(item.title)
                            if (!item.originalUrl.isNullOrBlank()) append("\n${item.originalUrl}")
                            if (item.summary.isNotBlank()) append("\n\nالنبذة: ${item.summary}")
                        }
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة الأداة"))
                    }) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "مشاركة", tint = BrainPrimary)
                    }
                    // Delete
                    IconButton(onClick = { onDelete(item.id) }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFEF4444))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BrainSurface)
            )
        },
        containerColor = BrainBackground
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Category Badge & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val catColor = category?.let { CategoryIconHelper.parseColor(it.colorHex) } ?: BrainPrimary
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(catColor.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Icon(
                        imageVector = CategoryIconHelper.getIcon(category?.iconKey ?: "folder"),
                        contentDescription = null,
                        tint = catColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = category?.nameArabic ?: "عام",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = catColor
                    )
                }

                Text(
                    text = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(item.createdAt)),
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title Field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("اسم الأداة / العنوان") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrainPrimary,
                    unfocusedBorderColor = BrainOutline
                ),
                shape = RoundedCornerShape(12.dp)
            )

            // Original URL launcher
            if (!item.originalUrl.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(BrainSurface)
                        .border(1.dp, BrainOutline, RoundedCornerShape(10.dp))
                        .clickable {
                            try {
                                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(item.originalUrl))
                                context.startActivity(browserIntent)
                            } catch (e: Exception) {
                                // invalid url ignore
                            }
                        }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.originalUrl,
                        fontSize = 13.sp,
                        color = BrainPrimary,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.OpenInBrowser,
                        contentDescription = "فتح في المتصفح",
                        tint = BrainPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Smart AI Summary Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = BrainSurface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = BrainSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "النبذة التوضيحية الذكية",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                        }

                        if (!item.originalUrl.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = {
                                    isReEnriching = true
                                    onReEnrich(item)
                                    isReEnriching = false
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                if (isReEnriching) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                } else {
                                    Text("تحديث AI", fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = summary,
                        onValueChange = { summary = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrainPrimary,
                            unfocusedBorderColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Rich Text Notes Section with Markdown Toolbar
            Text(
                text = "الملاحظات وتوثيق التجربة (Rich Text):",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B)
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Formatting Toolbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BrainSurfaceVariant, RoundedCornerShape(10.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(onClick = { notes = "$notes **نص عريض**" }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.FormatBold, contentDescription = "عريض", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { notes = "$notes *نص مائل*" }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.FormatItalic, contentDescription = "مائل", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { notes = "$notes\n- عنصر جديد" }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.FormatListBulleted, contentDescription = "قائمة", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { notes = "$notes\n```kotlin\n// اكتب كودك هنا\n```\n" }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.Code, contentDescription = "كود", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { notes = "$notes ==تمييز باللون==" }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.Highlight, contentDescription = "تمييز", modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                placeholder = { Text("اكتب ملاحظاتك، تجاربك، أو أكوادك هنا…") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("detail_notes_input"),
                minLines = 5,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrainPrimary,
                    unfocusedBorderColor = BrainOutline
                ),
                shape = RoundedCornerShape(12.dp)
            )

            // Offline Reader Archive section (if full text exists)
            if (item.offlineArchiveContent.isNotBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BrainSurface),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isArchiveExpanded = !isArchiveExpanded },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "الأرشيف المحلي للقراءة (Offline Reader)",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BrainPrimary
                                )
                                Text(
                                    text = "نسخة نصية محفوظة بالكامل للقراءة دون إنترنت",
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                            Icon(
                                imageVector = if (isArchiveExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = BrainPrimary
                            )
                        }

                        AnimatedVisibility(visible = isArchiveExpanded) {
                            Column {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = item.offlineArchiveContent,
                                    fontSize = 13.sp,
                                    lineHeight = 20.sp,
                                    color = Color(0xFF334155),
                                    modifier = Modifier
                                        .background(BrainBackground, RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // OCR section (if image/screenshot text was extracted)
            if (item.ocrExtractedText.isNotBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "النصوص والأكواد المستخرجة من الصورة (OCR):",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF166534)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = item.ocrExtractedText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = Color(0xFF14532D)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Test it Later Reminder row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(BrainSurface)
                    .border(1.dp, BrainOutline, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Alarm,
                        contentDescription = null,
                        tint = if (reminderTime != null) Color(0xFFD97706) else Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "تذكير (جرّبه لاحقاً)",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = if (reminderTime != null) {
                                SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(reminderTime!!))
                            } else {
                                "حدد موعداً لتجربة ومراجعة الأداة"
                            },
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                if (reminderTime == null) {
                    Button(
                        onClick = {
                            showDateTimePicker(context) { chosen ->
                                reminderTime = chosen
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrainPrimary)
                    ) {
                        Text("تحديد موعد", fontSize = 12.sp)
                    }
                } else {
                    IconButton(onClick = { reminderTime = null }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إلغاء التذكير", tint = Color.Red)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tags section
            Text(
                text = "الوسوم (Tags):",
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newTagInput,
                    onValueChange = { newTagInput = it },
                    placeholder = { Text("أضف وسماً…") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val trimmed = newTagInput.trim()
                        if (trimmed.isNotBlank()) {
                            val formatted = if (trimmed.startsWith("#")) trimmed else "#$trimmed"
                            if (!tags.contains(formatted)) tags.add(formatted)
                            newTagInput = ""
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrainPrimary)
                ) {
                    Text("إضافة")
                }
            }

            if (tags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    tags.forEach { tag ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color(0xFFE0E7FF), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = tag, fontSize = 12.sp, color = Color(0xFF3730A3))
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                tint = Color(0xFF4338CA),
                                modifier = Modifier
                                    .size(14.dp)
                                    .clickable { tags.remove(tag) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Save Changes Button
            Button(
                onClick = {
                    onSaveUpdate(
                        item.copy(
                            title = title,
                            summary = summary,
                            notesRichText = notes,
                            tags = tags.toList(),
                            reminderTimestamp = reminderTime
                        )
                    )
                    onBack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_detail_changes_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrainPrimary)
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("حفظ التعديلات في المستودع", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
