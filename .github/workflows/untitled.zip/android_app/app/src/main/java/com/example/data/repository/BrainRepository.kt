package com.example.data.repository

import android.content.Context
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.local.BrainDatabase
import com.example.data.model.BrainItem
import com.example.data.model.Category
import com.example.network.GeminiAiService
import com.example.network.WebScraper
import com.example.service.ReminderScheduler
import com.example.worker.LinkEnrichmentWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class BrainRepository(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val db = BrainDatabase.getDatabase(context, scope)
    private val itemDao = db.brainItemDao()
    private val categoryDao = db.categoryDao()
    private val workManager by lazy {
        try {
            WorkManager.getInstance(context)
        } catch (e: Throwable) {
            null
        }
    }

    val allActiveItems: Flow<List<BrainItem>> = itemDao.getAllActiveItems()
    val allCategories: Flow<List<Category>> = categoryDao.getAllCategories()
    val archivedItems: Flow<List<BrainItem>> = itemDao.getArchivedItems()
    val activeCount: Flow<Int> = itemDao.getActiveItemCount()

    fun searchItems(query: String): Flow<List<BrainItem>> {
        return if (query.isBlank()) {
            itemDao.getAllActiveItems()
        } else {
            itemDao.searchAllFields(query.trim())
        }
    }

    fun getItemsByCategory(categoryId: String): Flow<List<BrainItem>> {
        return itemDao.getItemsByCategory(categoryId)
    }

    fun getItemById(id: String): Flow<BrainItem?> {
        return itemDao.getItemById(id)
    }

    /**
     * Captures a new link, note, or idea and schedules background enrichment if a URL is provided.
     */
    suspend fun saveItem(
        title: String,
        url: String?,
        notes: String,
        categoryId: String,
        tags: List<String>,
        imageUri: String? = null,
        ocrText: String = "",
        reminderTime: Long? = null
    ): String = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val hasUrl = !url.isNullOrBlank()

        val initialSummary = if (hasUrl) {
            "جارٍ استخراج النبذة الذكية وتلخيص الموقع بالخلفية…"
        } else {
            notes.take(160).ifBlank { "ملاحظة وفكرة قيّمة محفوظة." }
        }

        val item = BrainItem(
            id = id,
            title = title.ifBlank { url ?: "فكرة جديدة" },
            summary = initialSummary,
            originalUrl = url,
            notesRichText = notes,
            categoryId = categoryId,
            tags = tags,
            imageUri = imageUri,
            ocrExtractedText = ocrText,
            reminderTimestamp = reminderTime,
            enrichmentStatus = if (hasUrl) "PENDING" else "READY"
        )

        itemDao.insertItem(item)

        // Schedule "Test it later" reminder if requested
        if (reminderTime != null && reminderTime > System.currentTimeMillis()) {
            ReminderScheduler.scheduleReminder(context, id, item.title, reminderTime)
        }

        // Schedule background WorkManager enrichment for URL
        if (hasUrl) {
            scheduleBackgroundEnrichment(id, url!!)
        }

        id
    }

    suspend fun updateItem(item: BrainItem) = withContext(Dispatchers.IO) {
        itemDao.updateItem(item.copy(updatedAt = System.currentTimeMillis()))
        if (item.reminderTimestamp != null && item.reminderTimestamp > System.currentTimeMillis()) {
            ReminderScheduler.scheduleReminder(context, item.id, item.title, item.reminderTimestamp)
        } else if (item.reminderTimestamp == null) {
            ReminderScheduler.cancelReminder(context, item.id)
        }
    }

    suspend fun togglePin(item: BrainItem) = withContext(Dispatchers.IO) {
        itemDao.updateItem(item.copy(isPinned = !item.isPinned))
    }

    suspend fun archiveItem(item: BrainItem) = withContext(Dispatchers.IO) {
        itemDao.updateItem(item.copy(isArchived = true))
    }

    suspend fun restoreItem(item: BrainItem) = withContext(Dispatchers.IO) {
        itemDao.updateItem(item.copy(isArchived = false))
    }

    suspend fun deleteItem(id: String) = withContext(Dispatchers.IO) {
        ReminderScheduler.cancelReminder(context, id)
        itemDao.deleteItemById(id)
    }

    suspend fun addCategory(category: Category) = withContext(Dispatchers.IO) {
        categoryDao.insertCategory(category)
    }

    suspend fun updateCategory(category: Category) = withContext(Dispatchers.IO) {
        categoryDao.updateCategory(category)
    }

    suspend fun deleteCategory(id: String) = withContext(Dispatchers.IO) {
        categoryDao.deleteCustomCategoryById(id)
    }

    suspend fun getAllCategoriesDirect(): List<Category> = withContext(Dispatchers.IO) {
        categoryDao.getAllCategoriesDirect()
    }

    suspend fun insertRestoredItems(items: List<BrainItem>) = withContext(Dispatchers.IO) {
        itemDao.insertItems(items)
    }

    suspend fun insertRestoredCategories(categories: List<Category>) = withContext(Dispatchers.IO) {
        categoryDao.insertCategories(categories)
    }

    suspend fun reEnrichItemNow(item: BrainItem): BrainItem = withContext(Dispatchers.IO) {
        val url = item.originalUrl
        if (url.isNullOrBlank()) return@withContext item

        val scraped = WebScraper.scrapeUrl(url)
        val ai = GeminiAiService.generateSummary(
            title = if (item.title.isNotBlank() && !item.title.startsWith("http")) item.title else scraped.title,
            url = url,
            rawContent = scraped.fullTextExcerpt.ifBlank { scraped.description }
        )

        val updated = item.copy(
            title = if (item.title.isBlank() || item.title.startsWith("http")) scraped.title.ifBlank { item.title } else item.title,
            summary = ai.summary.ifBlank { scraped.description },
            tags = (item.tags + ai.suggestedTags).distinct(),
            offlineArchiveContent = scraped.fullTextExcerpt,
            enrichmentStatus = "READY",
            updatedAt = System.currentTimeMillis()
        )
        itemDao.updateItem(updated)
        updated
    }

    private fun scheduleBackgroundEnrichment(itemId: String, url: String) {
        val inputData = Data.Builder()
            .putString(LinkEnrichmentWorker.KEY_ITEM_ID, itemId)
            .putString(LinkEnrichmentWorker.KEY_URL, url)
            .build()

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = OneTimeWorkRequestBuilder<LinkEnrichmentWorker>()
            .setInputData(inputData)
            .setConstraints(constraints)
            .build()

        workManager?.enqueue(request)
    }
}
