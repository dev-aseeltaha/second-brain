package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types

/**
 * Knowledge Vault Item entity: represents any captured tool, link, idea, or screenshot.
 */
@Entity(tableName = "brain_items")
data class BrainItem(
    @PrimaryKey
    val id: String,
    val title: String,
    val summary: String, // Smart AI summary / brief
    val originalUrl: String? = null,
    val notesRichText: String = "", // Rich markdown / notes
    val categoryId: String,
    val tags: List<String> = emptyList(), // e.g. ["#مجاني", "#تجربة_ضرورية"]
    val imageUri: String? = null, // Path to screenshot if captured
    val ocrExtractedText: String = "", // Text & code extracted from screenshot
    val offlineArchiveContent: String = "", // Full text offline reading archive
    val reminderTimestamp: Long? = null, // "Test it Later" scheduled epoch millis
    val isPinned: Boolean = false,
    val isLocked: Boolean = false, // Protected by PIN / Biometric
    val isArchived: Boolean = false,
    val enrichmentStatus: String = "READY", // PENDING, PROCESSING, READY, FAILED
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

class BrainTypeConverters {
    private val moshi = Moshi.Builder().build()
    private val listType = Types.newParameterizedType(List::class.java, String::class.java)
    private val adapter = moshi.adapter<List<String>>(listType)

    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        return if (list == null) "[]" else adapter.toJson(list)
    }

    @TypeConverter
    fun toStringList(json: String?): List<String> {
        return if (json.isNullOrBlank()) emptyList() else adapter.fromJson(json) ?: emptyList()
    }
}
