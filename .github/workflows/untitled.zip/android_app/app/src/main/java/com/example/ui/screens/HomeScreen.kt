package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrainItem
import com.example.data.model.Category
import com.example.ui.components.BrainItemCard
import com.example.ui.components.CategoryIconHelper
import com.example.ui.theme.BrainBackground
import com.example.ui.theme.BrainOutline
import com.example.ui.theme.BrainPrimary
import com.example.ui.theme.BrainSecondary
import com.example.ui.theme.BrainSurface
import com.example.ui.viewmodel.BrainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    items: List<BrainItem>,
    categories: List<Category>,
    selectedCategoryId: String?,
    selectedTag: String?,
    searchQuery: String,
    allTags: List<String>,
    isAppLockEnabled: Boolean,
    isGridLayout: Boolean,
    sortOption: BrainViewModel.SortOption,
    onToggleLayout: () -> Unit,
    onSetSortOption: (BrainViewModel.SortOption) -> Unit,
    onSearchChange: (String) -> Unit,
    onSelectCategory: (String?) -> Unit,
    onSelectTag: (String?) -> Unit,
    onItemClick: (BrainItem) -> Unit,
    onTogglePin: (BrainItem) -> Unit,
    onOpenQuickCapture: () -> Unit,
    onOpenCategoriesManage: () -> Unit,
    onOpenExport: () -> Unit,
    onOpenSettings: () -> Unit,
    onLockApp: () -> Unit
) {
    val pinnedItems = items.filter { it.isPinned }
    val regularItems = items.filter { !it.isPinned }
    var isSortMenuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "العقل الرقمي",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BrainPrimary
                        )
                        Text(
                            text = "صندوق ودائعك المعرفي الذكي",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                },
                actions = {
                    // Layout Toggle Button (Grid vs List)
                    IconButton(
                        onClick = onToggleLayout,
                        modifier = Modifier.testTag("toggle_layout_btn")
                    ) {
                        Icon(
                            imageVector = if (isGridLayout) Icons.Default.ViewList else Icons.Default.GridView,
                            contentDescription = if (isGridLayout) "عرض قائمة" else "عرض شبكة",
                            tint = BrainPrimary
                        )
                    }

                    // Sort Menu Button
                    Box {
                        IconButton(
                            onClick = { isSortMenuExpanded = true },
                            modifier = Modifier.testTag("sort_menu_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sort,
                                contentDescription = "ترتيب العناصر",
                                tint = BrainPrimary
                            )
                        }
                        DropdownMenu(
                            expanded = isSortMenuExpanded,
                            onDismissRequest = { isSortMenuExpanded = false }
                        ) {
                            BrainViewModel.SortOption.values().forEach { option ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (sortOption == option) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = null,
                                                    tint = BrainPrimary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                            }
                                            Text(
                                                text = option.titleArabic,
                                                fontWeight = if (sortOption == option) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 13.sp
                                            )
                                        }
                                    },
                                    onClick = {
                                        onSetSortOption(option)
                                        isSortMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Lock vault button (if enabled)
                    if (isAppLockEnabled) {
                        IconButton(onClick = onLockApp) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = "قفل الخزنة", tint = Color(0xFFD97706))
                        }
                    }
                    // Categories manager button
                    IconButton(onClick = onOpenCategoriesManage, modifier = Modifier.testTag("manage_categories_btn")) {
                        Icon(imageVector = Icons.Default.Widgets, contentDescription = "إدارة التصنيفات", tint = BrainPrimary)
                    }
                    // Export button
                    IconButton(onClick = onOpenExport, modifier = Modifier.testTag("export_data_btn")) {
                        Icon(imageVector = Icons.Default.IosShare, contentDescription = "تصدير المستودع", tint = BrainPrimary)
                    }
                    // Settings button
                    IconButton(onClick = onOpenSettings, modifier = Modifier.testTag("settings_btn")) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "الإعدادات", tint = BrainPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BrainSurface)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenQuickCapture,
                containerColor = BrainPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("add_item_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("التقاط فكرة / أداة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        },
        containerColor = BrainBackground
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .statusBarsPadding()
        ) {
            // Central Search Bar
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = {
                        Text(
                            text = "ابحث في العناوين، الروابط، والملاحظات…",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )
                    },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = BrainPrimary)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح", tint = Color(0xFF64748B))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input")
                )
            }

            // Categories Filter Row
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // "All" Category Pill
                item {
                    val isAllSelected = selectedCategoryId == null
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isAllSelected) BrainPrimary else BrainSurface)
                            .border(1.dp, if (isAllSelected) BrainPrimary else BrainOutline, RoundedCornerShape(10.dp))
                            .clickable { onSelectCategory(null) }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                            .testTag("category_all")
                    ) {
                        Text(
                            text = "كافة الأدوات",
                            fontSize = 12.5.sp,
                            fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isAllSelected) Color.White else Color(0xFF1E293B)
                        )
                    }
                }

                if (categories.isEmpty()) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(BrainSurface)
                                .border(1.dp, BrainOutline, RoundedCornerShape(10.dp))
                                .clickable { onOpenCategoriesManage() }
                                .padding(horizontal = 10.dp, vertical = 7.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = BrainSecondary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "+ إنشاء تصنيف", fontSize = 12.sp, color = BrainSecondary, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    items(categories) { cat ->
                        val isSelected = selectedCategoryId == cat.id
                        val catColor = CategoryIconHelper.parseColor(cat.colorHex)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) catColor else BrainSurface)
                                .border(1.dp, if (isSelected) catColor else BrainOutline, RoundedCornerShape(10.dp))
                                .clickable { onSelectCategory(cat.id) }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                                .testTag("category_chip_${cat.id}")
                        ) {
                            Icon(
                                imageVector = CategoryIconHelper.getIcon(cat.iconKey),
                                contentDescription = null,
                                tint = if (isSelected) Color.White else catColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = cat.nameArabic,
                                fontSize = 12.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else Color(0xFF1E293B)
                            )
                            if (cat.isProtected) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "محمي",
                                    tint = if (isSelected) Color.White else Color(0xFFD97706),
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Tags Filter Row (if tags exist)
            if (allTags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(allTags) { tag ->
                        val isTagSelected = selectedTag == tag
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isTagSelected) Color(0xFF4338CA) else Color(0xFFE0E7FF))
                                .clickable { onSelectTag(tag) }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = tag,
                                fontSize = 11.5.sp,
                                fontWeight = if (isTagSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isTagSelected) Color.White else Color(0xFF3730A3)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Main Items Content (Grid vs List)
            if (items.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEEF2FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = null,
                                tint = BrainPrimary,
                                modifier = Modifier.size(38.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "لم يتم العثور على نتائج بحث" else "مستودعك المعرفي فارغ حالياً",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) {
                                "جرب البحث بكلمات أخرى أو اختر تصنيفاً مختلفاً"
                            } else {
                                "اضغط على زر (التقاط فكرة / أداة) بالأسفل لحفظ أول رابط أو أداة أو صورة، أو قم بمشاركة الروابط مباشرة من متصفحك أو يوتيوب."
                            },
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else if (isGridLayout) {
                // Grid View (2 Columns)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (pinnedItems.isNotEmpty()) {
                        item(span = { GridItemSpan(2) }) {
                            Text(
                                text = "📌 المثبتة في الأعلى (${pinnedItems.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrainPrimary,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                        items(pinnedItems, key = { it.id }) { item ->
                            val cat = categories.find { it.id == item.categoryId }
                            BrainItemCard(
                                item = item,
                                category = cat,
                                onClick = { onItemClick(item) },
                                onTogglePin = { onTogglePin(item) }
                            )
                        }
                        item(span = { GridItemSpan(2) }) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "🗂️ كافة المحتويات (${regularItems.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF475569),
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    }

                    items(regularItems, key = { it.id }) { item ->
                        val cat = categories.find { it.id == item.categoryId }
                        BrainItemCard(
                            item = item,
                            category = cat,
                            onClick = { onItemClick(item) },
                            onTogglePin = { onTogglePin(item) }
                        )
                    }
                }
            } else {
                // List View (Single Column)
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (pinnedItems.isNotEmpty()) {
                        item {
                            Text(
                                text = "📌 المثبتة في الأعلى (${pinnedItems.size})",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrainPrimary,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                        items(pinnedItems, key = { it.id }) { item ->
                            val cat = categories.find { it.id == item.categoryId }
                            BrainItemCard(
                                item = item,
                                category = cat,
                                onClick = { onItemClick(item) },
                                onTogglePin = { onTogglePin(item) }
                            )
                        }
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "🗂️ كافة المحتويات (${regularItems.size})",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF475569),
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    }

                    items(regularItems, key = { it.id }) { item ->
                        val cat = categories.find { it.id == item.categoryId }
                        BrainItemCard(
                            item = item,
                            category = cat,
                            onClick = { onItemClick(item) },
                            onTogglePin = { onTogglePin(item) }
                        )
                    }
                }
            }
        }
    }
}
