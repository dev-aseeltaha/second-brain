package com.example.network

import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiSummaryResult(
    val summary: String,
    val keyPoints: List<String>,
    val suggestedTags: List<String>,
    val suggestedCategory: String?
)

object GeminiAiService {

    private const val TAG = "GeminiAiService"
    // Using recommended gemini-3.5-flash model for text and multimodal tasks
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun getApiKey(): String {
        return try {
            BuildConfig.GEMINI_API_KEY.trim()
        } catch (e: Throwable) {
            ""
        }
    }

    /**
     * Generates a concise, high-value Arabic summary and tags for an added link or tool.
     */
    suspend fun generateSummary(
        title: String,
        url: String?,
        rawContent: String
    ): AiSummaryResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Local high-quality heuristic fallback
            return@withContext fallbackSummary(title, url, rawContent)
        }

        try {
            val prompt = """
                أنت المساعد المكتبي لتطبيق (العقل الرقمي الثاني).
                المستخدم قام بإضافة أداة أو رابط أو مقال جديد.
                العنوان: $title
                الرابط: ${url ?: "لا يوجد"}
                المحتوى المستخرج: ${rawContent.take(2000)}

                المطلوب:
                1. نبذة ذكية ملخصة باللغة العربية تشرح وظيفة هذه الأداة/الموقع وما فائدتها للمستخدم في سطرين إلى ثلاثة فقط.
                2. قائمة بـ 2 إلى 3 نقاط رئيسية.
                3. قائمة من 2 إلى 4 وسوم تصنيف باللغة العربية تبدأ بـ # (مثال: #ذكاء_اصطناعي #مفتوح_المصدر #أدوات_مجانية).
                4. التصنيف الأنسب من بين: (ai_tools, android_apps, open_source, windows_software, ai_agents, ideas_later).

                أجب بتنسيق JSON حصراً بالشكل التالي:
                {
                  "summary": "نص النبذة هنا",
                  "keyPoints": ["نقطة 1", "نقطة 2"],
                  "suggestedTags": ["#وسم1", "#وسم2"],
                  "suggestedCategory": "ai_tools"
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        }
                        put("parts", parts)
                    })
                }
                put("contents", contents)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.3)
                    put("responseMimeType", "application/json")
                })
            }

            val endpoint = "$BASE_URL/$MODEL_NAME:generateContent?key=$apiKey"
            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.w(TAG, "Gemini API error: ${response.code} $responseBody")
                return@withContext fallbackSummary(title, url, rawContent)
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val content = candidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text") ?: ""

            parseAiResponseJson(text, title, url, rawContent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed calling Gemini API", e)
            fallbackSummary(title, url, rawContent)
        }
    }

    /**
     * Optical Character Recognition (OCR) via Gemini 3.5 Flash multimodal vision.
     * Extracts text, code snippets, and key headers from screenshots.
     */
    suspend fun extractTextFromImage(imageBytes: ByteArray): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "لقطة شاشة محفوظة (لتفعيل استخراج النصوص المتقدم OCR عبر Gemini، أضف مفتاح API في لوحة الأسرار)."
        }

        try {
            val base64Image = Base64.encodeToString(imageBytes, Base64.NO_WRAP)
            val prompt = "اقرأ واستخرج بدقة جميع النصوص، الأكواد البرمجية، العناوين، والروابط الظاهرة داخل هذه الصورة أو لقطة الشاشة حتى يتمكن المستخدم من البحث عنها والرجوع إليها."

            val requestJson = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", base64Image)
                                })
                            })
                        }
                        put("parts", parts)
                    })
                }
                put("contents", contents)
            }

            val endpoint = "$BASE_URL/$MODEL_NAME:generateContent?key=$apiKey"
            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val jsonResponse = JSONObject(responseBody)
                val candidates = jsonResponse.optJSONArray("candidates")
                val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                parts?.optJSONObject(0)?.optString("text") ?: ""
            } else {
                "تم حفظ لقطة الشاشة بنجاح."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed image OCR with Gemini", e)
            "تم حفظ لقطة الشاشة بنجاح."
        }
    }

    private fun parseAiResponseJson(
        jsonString: String,
        title: String,
        url: String?,
        rawContent: String
    ): AiSummaryResult {
        return try {
            val cleanJson = jsonString.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val obj = JSONObject(cleanJson)
            val summary = obj.optString("summary")
            val keyPointsList = mutableListOf<String>()
            val keyPointsArray = obj.optJSONArray("keyPoints")
            if (keyPointsArray != null) {
                for (i in 0 until keyPointsArray.length()) {
                    keyPointsList.add(keyPointsArray.getString(i))
                }
            }
            val tagsList = mutableListOf<String>()
            val tagsArray = obj.optJSONArray("suggestedTags")
            if (tagsArray != null) {
                for (i in 0 until tagsArray.length()) {
                    val tag = tagsArray.getString(i)
                    tagsList.add(if (tag.startsWith("#")) tag else "#$tag")
                }
            }
            val category = obj.optString("suggestedCategory").takeIf { it.isNotBlank() }

            AiSummaryResult(
                summary = if (summary.isNotBlank()) summary else title,
                keyPoints = keyPointsList,
                suggestedTags = tagsList,
                suggestedCategory = category
            )
        } catch (e: Exception) {
            fallbackSummary(title, url, rawContent)
        }
    }

    private fun fallbackSummary(title: String, url: String?, rawContent: String): AiSummaryResult {
        val cleanExcerpt = rawContent.trim()
        val summary = when {
            cleanExcerpt.isNotBlank() -> cleanExcerpt.take(200) + if (cleanExcerpt.length > 200) "…" else ""
            !url.isNullOrBlank() -> "أداة ورابط معرفي محفوظ للمراجعة والاستخدام: $url"
            else -> "فكرة وملاحظة قيّمة محفوظة في العقل الرقمي لتنفيذها لاحقاً."
        }

        val tags = mutableListOf<String>()
        val lowerUrl = (url ?: "").lowercase()
        if (lowerUrl.contains("github")) tags.add("#مفتوح_المصدر")
        if (lowerUrl.contains("play.google")) tags.add("#تطبيق_أندرويد")
        if (lowerUrl.contains("ai") || title.contains("AI", ignoreCase = true) || title.contains("ذكاء")) tags.add("#ذكاء_اصطناعي")
        if (tags.isEmpty()) tags.add("#أدوات")

        return AiSummaryResult(
            summary = summary,
            keyPoints = listOf("تم الحفظ في المستودع المحلي", "متاح بدون اتصال بالإنترنت"),
            suggestedTags = tags,
            suggestedCategory = null
        )
    }
}
