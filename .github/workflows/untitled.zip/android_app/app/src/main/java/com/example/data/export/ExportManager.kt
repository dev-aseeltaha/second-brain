package com.example.data.export

import android.content.Context
import android.content.Intent
import com.example.data.model.BrainItem
import com.example.data.model.Category
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExportManager {

    fun exportToJson(items: List<BrainItem>, categories: List<Category>): String {
        val root = JSONObject()
        root.put("app", "العقل الرقمي - Second Brain")
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
        root.put("totalItems", items.size)

        val categoriesArray = JSONArray()
        for (cat in categories) {
            val catObj = JSONObject().apply {
                put("id", cat.id)
                put("name", cat.nameArabic)
                put("icon", cat.iconKey)
                put("color", cat.colorHex)
            }
            categoriesArray.put(catObj)
        }
        root.put("categories", categoriesArray)

        val itemsArray = JSONArray()
        for (item in items) {
            val itemObj = JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("summary", item.summary)
                put("originalUrl", item.originalUrl ?: "")
                put("notes", item.notesRichText)
                put("category", item.categoryId)
                put("tags", JSONArray(item.tags))
                put("ocrText", item.ocrExtractedText)
                put("offlineArchive", item.offlineArchiveContent)
                put("createdAt", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(item.createdAt)))
            }
            itemsArray.put(itemObj)
        }
        root.put("items", itemsArray)

        return root.toString(2)
    }

    fun exportToMarkdown(items: List<BrainItem>, categories: List<Category>): String {
        val sb = StringBuilder()
        sb.append("# أرشيف العقل الرقمي (المستودع المعرفي)\n\n")
        sb.append("> تم التصدير بتاريخ: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())}\n")
        sb.append("> إجمالي العناصر المحفوظة: ${items.size}\n\n---\n\n")

        val catMap = categories.associateBy { it.id }
        val grouped = items.groupBy { it.categoryId }

        for ((catId, catItems) in grouped) {
            val catName = catMap[catId]?.nameArabic ?: catId
            sb.append("## 📁 $catName (${catItems.size})\n\n")

            for (item in catItems) {
                sb.append("### 📌 ${item.title}\n\n")
                if (!item.originalUrl.isNullOrBlank()) {
                    sb.append("- **الرابط:** [${item.originalUrl}](${item.originalUrl})\n")
                }
                if (item.tags.isNotEmpty()) {
                    sb.append("- **الوسوم:** ${item.tags.joinToString(" ")}\n")
                }
                sb.append("- **النبذة الذكية:**\n\n> ${item.summary.replace("\n", "\n> ")}\n\n")

                if (item.notesRichText.isNotBlank()) {
                    sb.append("#### الملاحظات:\n${item.notesRichText}\n\n")
                }

                if (item.ocrExtractedText.isNotBlank()) {
                    sb.append("#### نصوص مستخرجة من لقطة الشاشة (OCR):\n```\n${item.ocrExtractedText}\n```\n\n")
                }

                if (item.offlineArchiveContent.isNotBlank()) {
                    sb.append("<details><summary>نسخة المقال المحفوظة محلياً</summary>\n\n${item.offlineArchiveContent}\n\n</details>\n\n")
                }
                sb.append("---\n\n")
            }
        }
        return sb.toString()
    }

    fun shareExport(context: Context, content: String, title: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, content)
        }
        val chooser = Intent.createChooser(shareIntent, "مشاركة وتصدير المستودع المعرفي")
        context.startActivity(chooser)
    }
}
