package com.example.data.local

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.data.model.BrainItem
import com.example.data.model.BrainTypeConverters
import com.example.data.model.Category
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Robust Native SQLite-backed Database implementation.
 * Eliminates flaky KSP compiler plugins while guaranteeing full Offline-First persistence and reactive Flow updates.
 */
class BrainDatabase private constructor(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    private val dbScope = CoroutineScope(Dispatchers.IO)
    private val itemDao = BrainItemDaoImpl(this, dbScope)
    private val categoryDao = CategoryDaoImpl(this, dbScope)

    fun brainItemDao(): BrainItemDao = itemDao
    fun categoryDao(): CategoryDao = categoryDao

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS brain_items (
                id TEXT PRIMARY KEY NOT NULL,
                title TEXT NOT NULL,
                summary TEXT NOT NULL,
                originalUrl TEXT,
                notesRichText TEXT NOT NULL,
                categoryId TEXT NOT NULL,
                tags TEXT NOT NULL,
                imageUri TEXT,
                ocrExtractedText TEXT NOT NULL,
                offlineArchiveContent TEXT NOT NULL,
                reminderTimestamp INTEGER,
                isPinned INTEGER NOT NULL,
                isLocked INTEGER NOT NULL,
                isArchived INTEGER NOT NULL,
                enrichmentStatus TEXT NOT NULL,
                createdAt INTEGER NOT NULL,
                updatedAt INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS categories (
                id TEXT PRIMARY KEY NOT NULL,
                nameArabic TEXT NOT NULL,
                iconKey TEXT NOT NULL,
                colorHex TEXT NOT NULL,
                isSystemDefault INTEGER NOT NULL,
                isProtected INTEGER NOT NULL,
                sortOrder INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Backward-compatible schema evolution
    }

    companion object {
        private const val DATABASE_NAME = "mind_vault_second_brain.db"
        private const val DATABASE_VERSION = 1

        @Volatile
        private var INSTANCE: BrainDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): BrainDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = BrainDatabase(context)
                INSTANCE = instance
                instance
            }
        }
    }
}

class BrainItemDaoImpl(
    private val dbHelper: BrainDatabase,
    private val scope: CoroutineScope
) : BrainItemDao {

    private val typeConverters = BrainTypeConverters()
    private val _itemsFlow = MutableStateFlow<List<BrainItem>>(emptyList())

    init {
        scope.launch {
            refreshFromDb()
        }
    }

    private suspend fun refreshFromDb() = withContext(Dispatchers.IO) {
        val list = mutableListOf<BrainItem>()
        val db = dbHelper.readableDatabase
        val cursor: Cursor = db.rawQuery(
            "SELECT * FROM brain_items ORDER BY isPinned DESC, createdAt DESC",
            null
        )
        cursor.use { c ->
            val idCol = c.getColumnIndexOrThrow("id")
            val titleCol = c.getColumnIndexOrThrow("title")
            val summaryCol = c.getColumnIndexOrThrow("summary")
            val urlCol = c.getColumnIndexOrThrow("originalUrl")
            val notesCol = c.getColumnIndexOrThrow("notesRichText")
            val catCol = c.getColumnIndexOrThrow("categoryId")
            val tagsCol = c.getColumnIndexOrThrow("tags")
            val imgCol = c.getColumnIndexOrThrow("imageUri")
            val ocrCol = c.getColumnIndexOrThrow("ocrExtractedText")
            val archiveCol = c.getColumnIndexOrThrow("offlineArchiveContent")
            val reminderCol = c.getColumnIndexOrThrow("reminderTimestamp")
            val pinCol = c.getColumnIndexOrThrow("isPinned")
            val lockCol = c.getColumnIndexOrThrow("isLocked")
            val archCol = c.getColumnIndexOrThrow("isArchived")
            val statusCol = c.getColumnIndexOrThrow("enrichmentStatus")
            val createdCol = c.getColumnIndexOrThrow("createdAt")
            val updatedCol = c.getColumnIndexOrThrow("updatedAt")

            while (c.moveToNext()) {
                val item = BrainItem(
                    id = c.getString(idCol),
                    title = c.getString(titleCol),
                    summary = c.getString(summaryCol),
                    originalUrl = if (c.isNull(urlCol)) null else c.getString(urlCol),
                    notesRichText = c.getString(notesCol),
                    categoryId = c.getString(catCol),
                    tags = typeConverters.toStringList(c.getString(tagsCol)),
                    imageUri = if (c.isNull(imgCol)) null else c.getString(imgCol),
                    ocrExtractedText = c.getString(ocrCol),
                    offlineArchiveContent = c.getString(archiveCol),
                    reminderTimestamp = if (c.isNull(reminderCol)) null else c.getLong(reminderCol),
                    isPinned = c.getInt(pinCol) != 0,
                    isLocked = c.getInt(lockCol) != 0,
                    isArchived = c.getInt(archCol) != 0,
                    enrichmentStatus = c.getString(statusCol),
                    createdAt = c.getLong(createdCol),
                    updatedAt = c.getLong(updatedCol)
                )
                list.add(item)
            }
        }
        _itemsFlow.value = list
    }

    override fun getAllActiveItems(): Flow<List<BrainItem>> {
        return _itemsFlow.map { list -> list.filter { !it.isArchived } }
    }

    override fun getItemsByCategory(categoryId: String): Flow<List<BrainItem>> {
        return _itemsFlow.map { list -> list.filter { !it.isArchived && it.categoryId == categoryId } }
    }

    override fun searchAllFields(query: String): Flow<List<BrainItem>> {
        val q = query.trim().lowercase()
        return _itemsFlow.map { list ->
            if (q.isBlank()) {
                list.filter { !it.isArchived }
            } else {
                list.filter { item ->
                    !item.isArchived && (
                        item.title.lowercase().contains(q) ||
                        item.summary.lowercase().contains(q) ||
                        (item.originalUrl?.lowercase()?.contains(q) == true) ||
                        item.notesRichText.lowercase().contains(q) ||
                        item.ocrExtractedText.lowercase().contains(q) ||
                        item.tags.any { it.lowercase().contains(q) }
                    )
                }
            }
        }
    }

    override fun getItemById(id: String): Flow<BrainItem?> {
        return _itemsFlow.map { it.find { item -> item.id == id } }
    }

    override suspend fun getItemByIdDirect(id: String): BrainItem? = withContext(Dispatchers.IO) {
        _itemsFlow.value.find { it.id == id }
    }

    override suspend fun getPendingEnrichmentItems(): List<BrainItem> = withContext(Dispatchers.IO) {
        _itemsFlow.value.filter { it.enrichmentStatus == "PENDING" }
    }

    override fun getArchivedItems(): Flow<List<BrainItem>> {
        return _itemsFlow.map { list -> list.filter { it.isArchived } }
    }

    override suspend fun insertItem(item: BrainItem) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("id", item.id)
            put("title", item.title)
            put("summary", item.summary)
            put("originalUrl", item.originalUrl)
            put("notesRichText", item.notesRichText)
            put("categoryId", item.categoryId)
            put("tags", typeConverters.fromStringList(item.tags))
            put("imageUri", item.imageUri)
            put("ocrExtractedText", item.ocrExtractedText)
            put("offlineArchiveContent", item.offlineArchiveContent)
            put("reminderTimestamp", item.reminderTimestamp)
            put("isPinned", if (item.isPinned) 1 else 0)
            put("isLocked", if (item.isLocked) 1 else 0)
            put("isArchived", if (item.isArchived) 1 else 0)
            put("enrichmentStatus", item.enrichmentStatus)
            put("createdAt", item.createdAt)
            put("updatedAt", item.updatedAt)
        }
        db.insertWithOnConflict("brain_items", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        refreshFromDb()
    }

    override suspend fun insertItems(items: List<BrainItem>) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        db.beginTransaction()
        try {
            for (item in items) {
                val values = ContentValues().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("summary", item.summary)
                    put("originalUrl", item.originalUrl)
                    put("notesRichText", item.notesRichText)
                    put("categoryId", item.categoryId)
                    put("tags", typeConverters.fromStringList(item.tags))
                    put("imageUri", item.imageUri)
                    put("ocrExtractedText", item.ocrExtractedText)
                    put("offlineArchiveContent", item.offlineArchiveContent)
                    put("reminderTimestamp", item.reminderTimestamp)
                    put("isPinned", if (item.isPinned) 1 else 0)
                    put("isLocked", if (item.isLocked) 1 else 0)
                    put("isArchived", if (item.isArchived) 1 else 0)
                    put("enrichmentStatus", item.enrichmentStatus)
                    put("createdAt", item.createdAt)
                    put("updatedAt", item.updatedAt)
                }
                db.insertWithOnConflict("brain_items", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        refreshFromDb()
    }

    override suspend fun updateItem(item: BrainItem) = withContext(Dispatchers.IO) {
        insertItem(item)
    }

    override suspend fun deleteItem(item: BrainItem) = withContext(Dispatchers.IO) {
        deleteItemById(item.id)
    }

    override suspend fun deleteItemById(id: String) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        db.delete("brain_items", "id = ?", arrayOf(id))
        refreshFromDb()
    }

    override fun getActiveItemCount(): Flow<Int> {
        return _itemsFlow.map { it.count { !it.isArchived } }
    }
}

class CategoryDaoImpl(
    private val dbHelper: BrainDatabase,
    private val scope: CoroutineScope
) : CategoryDao {

    private val _categoriesFlow = MutableStateFlow<List<Category>>(emptyList())

    init {
        scope.launch {
            refreshFromDb()
        }
    }

    private suspend fun refreshFromDb() = withContext(Dispatchers.IO) {
        val list = mutableListOf<Category>()
        val db = dbHelper.readableDatabase
        val cursor: Cursor = db.rawQuery(
            "SELECT * FROM categories ORDER BY sortOrder ASC, id ASC",
            null
        )
        cursor.use { c ->
            val idCol = c.getColumnIndexOrThrow("id")
            val nameCol = c.getColumnIndexOrThrow("nameArabic")
            val iconCol = c.getColumnIndexOrThrow("iconKey")
            val colorCol = c.getColumnIndexOrThrow("colorHex")
            val defCol = c.getColumnIndexOrThrow("isSystemDefault")
            val lockCol = c.getColumnIndexOrThrow("isProtected")
            val orderCol = c.getColumnIndexOrThrow("sortOrder")

            while (c.moveToNext()) {
                val cat = Category(
                    id = c.getString(idCol),
                    nameArabic = c.getString(nameCol),
                    iconKey = c.getString(iconCol),
                    colorHex = c.getString(colorCol),
                    isSystemDefault = c.getInt(defCol) != 0,
                    isProtected = c.getInt(lockCol) != 0,
                    sortOrder = c.getInt(orderCol)
                )
                list.add(cat)
            }
        }
        _categoriesFlow.value = list
    }

    override fun getAllCategories(): Flow<List<Category>> {
        return _categoriesFlow.asStateFlow()
    }

    override suspend fun getAllCategoriesDirect(): List<Category> = withContext(Dispatchers.IO) {
        _categoriesFlow.value
    }

    override suspend fun getCategoryById(id: String): Category? = withContext(Dispatchers.IO) {
        _categoriesFlow.value.find { it.id == id }
    }

    override suspend fun insertCategory(category: Category) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("id", category.id)
            put("nameArabic", category.nameArabic)
            put("iconKey", category.iconKey)
            put("colorHex", category.colorHex)
            put("isSystemDefault", if (category.isSystemDefault) 1 else 0)
            put("isProtected", if (category.isProtected) 1 else 0)
            put("sortOrder", category.sortOrder)
        }
        db.insertWithOnConflict("categories", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        refreshFromDb()
    }

    override suspend fun insertCategories(categories: List<Category>) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        db.beginTransaction()
        try {
            for (cat in categories) {
                val values = ContentValues().apply {
                    put("id", cat.id)
                    put("nameArabic", cat.nameArabic)
                    put("iconKey", cat.iconKey)
                    put("colorHex", cat.colorHex)
                    put("isSystemDefault", if (cat.isSystemDefault) 1 else 0)
                    put("isProtected", if (cat.isProtected) 1 else 0)
                    put("sortOrder", cat.sortOrder)
                }
                db.insertWithOnConflict("categories", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        refreshFromDb()
    }

    override suspend fun updateCategory(category: Category) = withContext(Dispatchers.IO) {
        insertCategory(category)
    }

    override suspend fun deleteCategory(category: Category) = withContext(Dispatchers.IO) {
        deleteCustomCategoryById(category.id)
    }

    override suspend fun deleteCustomCategoryById(id: String) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        db.delete("categories", "id = ?", arrayOf(id))
        refreshFromDb()
    }
}
