package com.example.data.local

import com.example.data.model.Category
import kotlinx.coroutines.flow.Flow

interface CategoryDao {
    fun getAllCategories(): Flow<List<Category>>
    suspend fun getAllCategoriesDirect(): List<Category>
    suspend fun getCategoryById(id: String): Category?
    suspend fun insertCategory(category: Category)
    suspend fun insertCategories(categories: List<Category>)
    suspend fun updateCategory(category: Category)
    suspend fun deleteCategory(category: Category)
    suspend fun deleteCustomCategoryById(id: String)
}
