package com.example.ui.dialogs

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.export.ExportManager
import com.example.data.model.BrainItem
import com.example.data.model.Category
import com.example.ui.theme.BrainBackground
import com.example.ui.theme.BrainOutline
import com.example.ui.theme.BrainPrimary
import com.example.ui.theme.BrainSecondary
import com.example.ui.theme.BrainSurface

@Composable
fun ExportDialog(
    items: List<BrainItem>,
    categories: List<Category>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedFormat by remember { mutableStateOf("MARKDOWN") } // MARKDOWN or JSON

    val exportedContent = remember(selectedFormat, items.size) {
        if (selectedFormat == "MARKDOWN") {
            ExportManager.exportToMarkdown(items, categories)
        } else {
            ExportManager.exportToJson(items, categories)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تصدير المستودع المعرفي",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrainPrimary
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "بياناتك ملكك بالكامل. يمكنك تصدير كافة العناصر (${items.size} عنصر) والتصنيفات في أي وقت دون أي قيود.",
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    color = Color(0xFF475569)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Format selector buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Markdown card
                    val isMd = selectedFormat == "MARKDOWN"
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.5.dp, if (isMd) BrainPrimary else BrainOutline, RoundedCornerShape(12.dp))
                            .clickable { selectedFormat = "MARKDOWN" },
                        colors = CardDefaults.cardColors(containerColor = if (isMd) Color(0xFFEEF2FF) else BrainBackground)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                tint = if (isMd) BrainPrimary else Color(0xFF64748B),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "ملف Markdown",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isMd) BrainPrimary else Color(0xFF1E293B)
                            )
                            Text(
                                text = "منسق ومنظم للقراءة",
                                fontSize = 10.5.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    // JSON card
                    val isJson = selectedFormat == "JSON"
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.5.dp, if (isJson) BrainPrimary else BrainOutline, RoundedCornerShape(12.dp))
                            .clickable { selectedFormat = "JSON" },
                        colors = CardDefaults.cardColors(containerColor = if (isJson) Color(0xFFEEF2FF) else BrainBackground)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.DataObject,
                                contentDescription = null,
                                tint = if (isJson) BrainPrimary else Color(0xFF64748B),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "ملف JSON",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isJson) BrainPrimary else Color(0xFF1E293B)
                            )
                            Text(
                                text = "نسخة احتياطية برمجية",
                                fontSize = 10.5.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("BrainExport", exportedContent))
                            Toast.makeText(context, "تم نسخ محتوى التصدير إلى الحافظة!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نسخ النص", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            ExportManager.shareExport(
                                context,
                                exportedContent,
                                "أرشيف العقل الرقمي (${if (selectedFormat == "MARKDOWN") "Markdown" else "JSON"})"
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = BrainPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مشاركة وحفظ", fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("تم", fontWeight = FontWeight.Bold, color = BrainPrimary)
            }
        },
        containerColor = BrainSurface,
        shape = RoundedCornerShape(16.dp)
    )
}
