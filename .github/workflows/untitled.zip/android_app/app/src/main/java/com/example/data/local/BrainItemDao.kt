package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BrainItem
import kotlinx.coroutines.flow.Flow

@Dao
interface BrainItemDao {

    @Query("SELECT * FROM brain_items WHERE isArchived = 0 ORDER BY isPinned DESC, createdAt DESC")
    fun getAllActiveItems(): Flow<List<BrainItem>>

    @Query("SELECT * FROM brain_items WHERE isArchived = 0 AND categoryId = :categoryId ORDER BY isPinned DESC, createdAt DESC")
    fun getItemsByCategory(categoryId: String): Flow<List<BrainItem>>

    @Query("""
        SELECT * FROM brain_items 
        WHERE isArchived = 0 AND (
            title LIKE '%' || :query || '%' OR 
            summary LIKE '%' || :query || '%' OR 
            originalUrl LIKE '%' || :query || '%' OR 
            notesRichText LIKE '%' || :query || '%' OR 
            ocrExtractedText LIKE '%' || :query || '%' OR
            tags LIKE '%' || :query || '%'
        )
        ORDER BY isPinned DESC, createdAt DESC
    """)
    fun searchAllFields(query: String): Flow<List<BrainItem>>

    @Query("SELECT * FROM brain_items WHERE id = :id LIMIT 1")
    fun getItemById(id: String): Flow<BrainItem?>

    @Query("SELECT * FROM brain_items WHERE id = :id LIMIT 1")
    suspend fun getItemByIdDirect(id: String): BrainItem?

    @Query("SELECT * FROM brain_items WHERE enrichmentStatus = 'PENDING'")
    suspend fun getPendingEnrichmentItems(): List<BrainItem>

    @Query("SELECT * FROM brain_items WHERE isArchived = 1 ORDER BY updatedAt DESC")
    fun getArchivedItems(): Flow<List<BrainItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: BrainItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<BrainItem>)

    @Update
    suspend fun updateItem(item: BrainItem)

    @Delete
    suspend fun deleteItem(item: BrainItem)

    @Query("DELETE FROM brain_items WHERE id = :id")
    suspend fun deleteItemById(id: String)

    @Query("SELECT COUNT(*) FROM brain_items WHERE isArchived = 0")
    fun getActiveItemCount(): Flow<Int>
}
