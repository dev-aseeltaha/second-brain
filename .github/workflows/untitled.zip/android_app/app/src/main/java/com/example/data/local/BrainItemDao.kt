package com.example.data.local

import com.example.data.model.BrainItem
import kotlinx.coroutines.flow.Flow

interface BrainItemDao {
    fun getAllActiveItems(): Flow<List<BrainItem>>
    fun getItemsByCategory(categoryId: String): Flow<List<BrainItem>>
    fun searchAllFields(query: String): Flow<List<BrainItem>>
    fun getItemById(id: String): Flow<BrainItem?>
    suspend fun getItemByIdDirect(id: String): BrainItem?
    suspend fun getPendingEnrichmentItems(): List<BrainItem>
    fun getArchivedItems(): Flow<List<BrainItem>>
    suspend fun insertItem(item: BrainItem)
    suspend fun insertItems(items: List<BrainItem>)
    suspend fun updateItem(item: BrainItem)
    suspend fun deleteItem(item: BrainItem)
    suspend fun deleteItemById(id: String)
    fun getActiveItemCount(): Flow<Int>
}
