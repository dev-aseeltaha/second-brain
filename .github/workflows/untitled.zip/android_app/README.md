# العقل الرقمي الثاني (المستودع المعرفي الذكي) - Android App (Kotlin & Jetpack Compose)

تطبيق أندرويد متكامل بنظام هجين (Hybrid Offline-First) لإدارة وحفظ الروابط والأدوات والأفكار وتلخيصها بالذكاء الاصطناعي مع مزامنة سحابية وقفل أمني بالبصمة.

---

### الميزات المحدثة والمكتملة (Changelog & Completed Features):
1. **المزامنة السحابية عبر Firebase Firestore وحساب Google (`FirestoreSyncManager`)**:
   - تفعيل تبعيات `firebase-firestore`, `firebase-auth`, `credentials`, `googleid`.
   - إمكانية رفع ومزامنة كافة عناصر الـ Room Database والمجلدات إلى مجموعة `users/{userId}/brain_items` و `users/{userId}/categories`.
   - استعادة كاملة لقاعدة البيانات من السحابة بضغطة زر.
2. **التحقق البيومتري الحقيقي لنظام أندرويد (`BiometricPrompt`)**:
   - استخدام مكتبة `androidx.biometric:biometric` عبر `BiometricAuthHelper`.
   - دعم المصادقة بمستشعر البصمة وفتح الخزنة وقفل المجلدات بشكل رسمي.
3. **قفل وحماية المجلدات الحساسة (`CategoryLockDialog`)**:
   - حماية المجلدات المحددة كـ `isProtected` (مثل مجلد "أفكار للتنفيذ لاحقاً") برمز PIN أو البصمة البيومترية قبل السماح بعرض محتوياتها.
4. **دعم تذكيرات أندرويد الدقيقة (Android 12+ / 14+)**:
   - إضافة إذن `SCHEDULE_EXACT_ALARM` و `USE_EXACT_ALARM` لضمان عمل تنبيهات "جرّبه لاحقاً" في الموعد المحدد بدقة ثانية.
5. **محرر الملاحظات المتقدم (Rich Markdown Toolbar)**.
6. **التصدير الكامل لقاعدة البيانات (JSON & Markdown)**.
7. **الواجهة العربية الكاملة والنقية بدون وضع ليلي (Light Theme Exclusive)**.

---

### طريقة التشغيل في Android Studio:
1. افتح مجلد المشروع في [Android Studio](https://developer.android.com/studio).
2. قم بإعداد ملف `.env` ووضع مفتاح `GEMINI_API_KEY` الخاص بك.
3. قم ببناء المشروع (`Build -> Rebuild Project`) وتشغيله على المحاكي أو جهازك الحقيقي.
